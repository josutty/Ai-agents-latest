# AGENTS.md §11 — Key files and ownership

Part of AGENTS.md, kept in its own file so only the agents that need it load it.

## 11. Key files (who owns what — edit only files you own)

| Path | Owner |
|---|---|
| `analysis/capabilities.md` | wireframe-analyzer |
| `analysis/design-spec/**`, `analysis/display-rules.md` | wireframe-analyzer |
| `plan/run-options.md` | orchestrator (its only file) |
| page routes in `src/app/router.tsx`, `src/shared/config/routes.ts` | coder, via the page TASK's Files rows (app-bootstrap owns the rest of both files) |
| `plan/design-diff/**` | reviewer |
| `plan/design-accepted.md` | **humans only** — differences you accept on purpose (`| input "email" | border colour | reason |`); no agent edits it |
| `plan/requirements-questions.md` | library-advisor writes the questions · the human fills the Answer column |
| `plan/library-decisions.md` | library-advisor (rows + Details) · fsd-planner may add `needs-approval` rows · the human sets Status (`approve-libs`) |
| `analysis/**` | wireframe-analyzer |
| `plan/generated/api-spec.yaml`, `plan/generated/backend-gaps.md` | hybrid-api-config |
| `plan/generated/endpoints-map.json`, `src/shared/api/generated/**`, `notes/research/api-schema.md` | schema-parser |
| `mocks/**` | mock-data-generator |
| `plan/fsd-structure.md`, `plan/component-owners.md`, `plan/api-integration-points.md` | fsd-planner |
| `plan/tasks/**`, `plan/PROGRESS.md` | architect (the `status` column only: test-engineer → `in-progress`, reviewer → `done`) |
| `src/shared/api/*.ts` (not generated/), `src/app/store/**`, `src/shared/lib/store/**`, `src/*/*/api/**`, `src/*/*/model/**`, `plan/store-design.md` | store-architect |
| `tailwind.config.ts`, `src/shared/ui/theme/**`, `plan/design-system.md` | styling-engineer |
| `test/**`, `src/**/*.test.ts(x)`, `e2e/**` | test-engineer |
| `src/*/*/lib/**` (helpers, form schemas) | the owner named in the TASK Files table |
| presentational `ui/` files + `*.stories.tsx` (per TASK Files table) | component-generator |
| connected `ui/` files, `src/pages/**` (per TASK Files table) | coder |
| root configs, `.storybook/**`, `src/app/{main,App,router}.tsx`, `src/app/providers/**`, `src/shared/config/**`, `src/shared/lib/logger/**` | app-bootstrap |
| `PROJECT.md`, `notes/research/codebase-map.md` | codebase-scanner |
| `plan/coverage-matrix.md` | coverage-checker |
| `analysis/CHANGES.md` | wireframe-analyzer (delta runs) |
| `plan/generated/api-changes.md` | hybrid-api-config (delta runs) |
| `tools/**` (repo helper scripts) | app-bootstrap — except the files that ship with the team: `tools/hooks/**`, `task.mjs`, `design-spec.mjs`, `detect-ui-capabilities.mjs`, `check-install.mjs`, `list-html-elements.mjs`, `check-contrast.mjs`, `lib-facts.mjs`, `scope.mjs`, `port-drift.mjs`, `run.mjs`, `set-models.mjs` (humans only) |
| `notes/research/**` (except api-schema.md, codebase-map.md) | researcher |
| `notes/memory/reflections/**` | reflector |
| `plan/history/TASK-NNN.md` | append-only, any agent working on that task |
| `.opencode/**`, `agent-docs/**`, `opencode.json`, `models.json`, `.githooks/**`, `.github/workflows/**`, `.prettierrc.json` after Run 1 | humans only — agents never edit the team's own setup |
