export const routes = {
  products: '/',
  signIn: '/sign-in',
  account: '/account',
  indent: '/indent',
  login: '/login',
  loginWrong: '/login-wrong',
} as const;
