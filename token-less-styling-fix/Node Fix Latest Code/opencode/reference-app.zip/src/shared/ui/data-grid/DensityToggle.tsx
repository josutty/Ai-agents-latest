import { ToggleGroup } from 'radix-ui';
import type { Density } from './DataGrid';

export interface DensityToggleProps {
  value: Density;
  onChange: (value: Density) => void;
}

const item = 'rounded-control px-3 py-1.5 text-label text-fg-muted data-[state=on]:bg-surface data-[state=on]:font-semibold data-[state=on]:text-primary';

/** Segmented control (Radix ToggleGroup): arrow keys move, one option always selected. */
export function DensityToggle({ value, onChange }: DensityToggleProps) {
  return (
    <ToggleGroup.Root
      type="single"
      value={value}
      onValueChange={(v) => { if (v === 'comfortable' || v === 'compact') onChange(v); }}
      aria-label="Row density"
      className="inline-flex rounded-card bg-surface-muted p-0.5"
    >
      <ToggleGroup.Item value="comfortable" className={item}>Comfortable</ToggleGroup.Item>
      <ToggleGroup.Item value="compact" className={item}>Compact</ToggleGroup.Item>
    </ToggleGroup.Root>
  );
}
