import { DropdownMenu } from 'radix-ui';
import type { Table } from '@tanstack/react-table';
import { Button } from '../button/Button';

export interface ColumnsMenuProps<TData> {
  table: Table<TData>;
  /** Column ids that can be hidden (pinned columns usually can't). */
  hideable: { id: string; label: string }[];
}

/** Column picker (Radix DropdownMenu + TanStack column visibility). */
export function ColumnsMenu<TData>({ table, hideable }: ColumnsMenuProps<TData>) {
  return (
    <DropdownMenu.Root>
      <DropdownMenu.Trigger asChild>
        <Button variant="ghost" size="sm"><span aria-hidden="true">☷</span> Columns</Button>
      </DropdownMenu.Trigger>
      <DropdownMenu.Portal>
        <DropdownMenu.Content align="end" sideOffset={4} className="z-50 min-w-48 rounded-card border border-border bg-surface p-1 shadow-card">
          {hideable.map(({ id, label }) => {
            const column = table.getColumn(id);
            return column ? (
              <DropdownMenu.CheckboxItem
                key={id}
                checked={column.getIsVisible()}
                onCheckedChange={(checked) => column.toggleVisibility(checked)}
                onSelect={(e) => e.preventDefault()}
                className="flex cursor-default items-center gap-2 rounded-control px-2 py-1.5 text-body-sm text-fg outline-none data-[highlighted]:bg-surface-muted"
              >
                <span aria-hidden="true" className="w-4">{column.getIsVisible() ? '✓' : ''}</span>
                {label}
              </DropdownMenu.CheckboxItem>
            ) : null;
          })}
        </DropdownMenu.Content>
      </DropdownMenu.Portal>
    </DropdownMenu.Root>
  );
}
