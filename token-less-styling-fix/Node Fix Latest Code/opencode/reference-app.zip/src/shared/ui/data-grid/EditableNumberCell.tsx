import { useId, useState } from 'react';
import { handleGridKeyDown } from './gridKeyboard';

export interface EditableNumberCellProps {
  value: number;
  /** Previous value shown under the input ("was 25"); omit when there is none. */
  previous?: number;
  /** Accessible name, e.g. "W1 for H HSD 20FT BSVI NGB". */
  label: string;
  row: number;
  col: number;
  onCommit: (value: number) => void;
}

export function EditableNumberCell({ value, previous, label, row, col, onCommit }: EditableNumberCellProps) {
  const [draft, setDraft] = useState(String(value));
  const [synced, setSynced] = useState(value);
  if (synced !== value) { setSynced(value); setDraft(String(value)); } // value changed from outside
  const hintId = useId();

  const commit = () => {
    const next = Number(draft);
    if (draft.trim() === '' || !Number.isInteger(next) || next < 0) { setDraft(String(value)); return; }
    if (next !== value) onCommit(next);
  };

  return (
    <div className="flex flex-col items-end gap-0.5">
      <input
        type="text"
        inputMode="numeric"
        aria-label={label}
        aria-describedby={previous !== undefined ? hintId : undefined}
        data-row={row}
        data-col={col}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => { if (e.key === 'Escape') setDraft(String(value)); else handleGridKeyDown(e); }}
        className="w-14 rounded border border-border-strong bg-surface px-1.5 py-0.5 text-right text-body-sm tabular-nums"
      />
      {previous !== undefined ? <span id={hintId} className="text-micro text-fg-muted">was {previous}</span> : null}
    </div>
  );
}
