import type { ReactNode } from 'react';
import { flexRender, type Table } from '@tanstack/react-table';
import './columnMeta';

export type Density = 'comfortable' | 'compact';

export interface DataGridProps<TData> {
  /** A table instance from useReactTable (columns, pinning, visibility, filtering live with the caller). */
  table: Table<TData>;
  /** Accessible name of the grid, e.g. "Indent plan". */
  label: string;
  density?: Density;
  toolbar?: ReactNode;
  footer?: ReactNode;
}

const pad: Record<Density, string> = { comfortable: 'px-3 py-2.5', compact: 'px-3 py-1' };
const line = 'border-r border-border';

/** Grouped headers, pinned (frozen) columns, vertical lines, density, horizontal scroll. Cells style themselves via column meta. */
export function DataGrid<TData>({ table, label, density = 'comfortable', toolbar, footer }: DataGridProps<TData>) {
  const groups = table.getHeaderGroups();
  return (
    <div className="flex flex-col gap-3">
      {toolbar}
      <div className="mx-6 overflow-x-auto rounded-card border border-border">
        <table aria-label={label} className="w-max min-w-full border-collapse text-body-sm text-fg">
          <thead className="bg-surface-muted">
            {groups.map((group, gi) => {
              const leafRow = gi === groups.length - 1;
              return (
                <tr key={group.id}>
                  {group.headers.map((header) => (
                    <th
                      key={header.id}
                      colSpan={header.colSpan}
                      scope={header.colSpan > 1 ? 'colgroup' : 'col'}
                      className={`${pad[density]} ${line} whitespace-nowrap ${leafRow ? 'border-b text-label font-semibold text-fg' : 'text-left text-overline uppercase text-fg-muted'} ${header.column.getIsPinned() ? 'sticky left-0 z-20 bg-surface-muted' : ''} ${leafRow ? header.column.columnDef.meta?.headClass ?? '' : ''}`}
                    >
                      {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                    </th>
                  ))}
                </tr>
              );
            })}
          </thead>
          <tbody>
            {table.getRowModel().rows.map((row) => (
              <tr key={row.id}>
                {row.getVisibleCells().map((cell) => {
                  const content = flexRender(cell.column.columnDef.cell, cell.getContext());
                  const cls = `${pad[density]} ${line} border-b whitespace-nowrap ${cell.column.columnDef.meta?.cellClass ?? 'text-right tabular-nums'}`;
                  return cell.column.getIsPinned() ? (
                    <th key={cell.id} scope="row" className={`${cls} sticky left-0 z-10 bg-surface text-left`}>{content}</th>
                  ) : (
                    <td key={cell.id} className={cls}>{content}</td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {footer}
    </div>
  );
}
