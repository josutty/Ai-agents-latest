import type { KeyboardEvent } from 'react';

const MOVES: Record<string, readonly [number, number]> = {
  ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1], Enter: [1, 0],
};

/** Spreadsheet-style movement between editable cells (inputs carrying data-row / data-col). */
export function handleGridKeyDown(event: KeyboardEvent<HTMLInputElement>): void {
  const target = event.currentTarget;
  if (target.dataset.row === undefined) return;
  const move = MOVES[event.key];
  if (!move) return;
  const row = Number(target.dataset.row) + move[0];
  const col = Number(target.dataset.col) + move[1];
  const next = target.closest('table')?.querySelector<HTMLInputElement>(`input[data-row="${row}"][data-col="${col}"]`);
  if (!next) return;
  event.preventDefault();
  next.focus(); // the cell being left commits on blur
  next.select();
}
