import type { RowData } from '@tanstack/react-table';

// Per-column Tailwind classes, copied from the design spec (width, alignment, font, color).
declare module '@tanstack/react-table' {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars -- TanStack's declaration needs both type parameters
  interface ColumnMeta<TData extends RowData, TValue> {
    headClass?: string;
    cellClass?: string;
  }
}
export {};
