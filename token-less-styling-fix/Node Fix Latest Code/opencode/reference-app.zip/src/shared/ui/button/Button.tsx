import type { ButtonHTMLAttributes } from 'react';

type Variant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
type Size = 'sm' | 'md';

const variants: Record<Variant, string> = {
  primary: 'bg-primary text-primary-fg hover:bg-primary/90',
  secondary: 'border border-border-strong bg-surface text-fg hover:bg-surface-muted',
  outline: 'border border-primary bg-transparent text-primary hover:bg-primary/5',
  ghost: 'border border-transparent bg-transparent text-fg hover:bg-surface-muted',
  danger: 'bg-danger text-danger-fg hover:bg-danger/90',
};
const sizes: Record<Size, string> = { sm: 'h-9 px-3.5', md: 'min-h-10 px-4' };

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
}

export function Button({ variant = 'primary', size = 'md', loading = false, disabled, className = '', children, type = 'button', ...rest }: ButtonProps) {
  return (
    <button
      type={type}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={`inline-flex items-center justify-center gap-2 rounded-control text-body-sm font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-60 ${sizes[size]} ${variants[variant]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}
