const priceFormat = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });
export const formatPrice = (value: number): string => priceFormat.format(value);

/** Design rule: empty / missing counts show as an en dash. */
export const formatCount = (value: number | null | undefined): string => (value == null ? '–' : String(value));
