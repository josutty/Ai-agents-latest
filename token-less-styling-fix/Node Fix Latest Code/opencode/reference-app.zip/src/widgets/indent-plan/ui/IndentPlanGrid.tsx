import { useMemo, useState } from 'react';
import { createColumnHelper, getCoreRowModel, getFilteredRowModel, useReactTable } from '@tanstack/react-table';
import { Button } from '@shared/ui';
import { ColumnsMenu, DataGrid, DensityToggle, EditableNumberCell, type Density } from '@shared/ui/data-grid';
import { formatCount } from '@shared/lib/format';

export type StockTone = 'low' | 'warn' | 'ok';

export interface IndentLine {
  id: string;
  description: string;
  fertCode: string;
  mpg: string;
  stock: number;
  /** Display rule from the design: low → danger, warn → warning. Decided by the backend (open question Q1). */
  stockTone: StockTone;
  livePos: number | null;
  pipeline: { confirmed: number; fa: number; fc: number; hotInq: number };
  offtakeL3: number;
  retailL3: number;
  weeks: number[];
  previousWeeks: number[];
}

export interface IndentPlanGridProps {
  lines: IndentLine[];
  monthLabel: string;
  onChangeWeek: (lineId: string, week: number, value: number) => void;
}

const WEEKS = ['W1', 'W2', 'W3', 'W4'] as const;
const TONE: Record<StockTone, string> = { low: 'font-semibold text-danger', warn: 'font-semibold text-warning', ok: '' };
const h = createColumnHelper<IndentLine>();
const single = (id: string, label: string, leaf: ReturnType<typeof h.accessor>) => h.group({ id: `${id}Group`, header: label, columns: [leaf] });

export function IndentPlanGrid({ lines, monthLabel, onChangeWeek }: IndentPlanGridProps) {
  const [search, setSearch] = useState('');
  const [density, setDensity] = useState<Density>('comfortable');

  const columns = useMemo(() => [
    h.accessor('description', {
      id: 'description', header: 'Description',
      meta: { headClass: 'w-64 min-w-64 text-left', cellClass: 'w-64 min-w-64 font-semibold' },
      cell: ({ getValue }) => (
        <span className="inline-flex items-center gap-2">
          {getValue()}
          <button type="button" aria-label={`Details for ${getValue()}`} className="grid size-[22px] place-items-center rounded-control border border-border bg-surface text-caption text-fg-muted">ⓘ</button>
        </span>
      ),
    }),
    single('fertCode', 'Fert code', h.accessor('fertCode', { id: 'fertCode', header: 'FERT code', meta: { cellClass: 'text-left font-mono text-accent' } })),
    single('mpg', 'MPG', h.accessor('mpg', { id: 'mpg', header: 'MPG', meta: { cellClass: 'text-left' } })),
    single('stock', 'Stock ▸', h.accessor('stock', { id: 'stock', header: 'Stock', cell: ({ row, getValue }) => <span className={TONE[row.original.stockTone]}>{getValue()}</span> })),
    single('livePos', 'Live POs ▸', h.accessor('livePos', { id: 'livePos', header: 'Live POs', cell: ({ getValue }) => formatCount(getValue()) })),
    h.group({ id: 'pipeline', header: 'Pipeline ▸', columns: [
      h.accessor((r) => r.pipeline.confirmed, { id: 'confirmed', header: 'Confirmed' }),
      h.accessor((r) => r.pipeline.fa, { id: 'fa', header: 'FA' }),
      h.accessor((r) => r.pipeline.fc, { id: 'fc', header: 'FC' }),
      h.accessor((r) => r.pipeline.hotInq, { id: 'hotInq', header: 'Hot Inq' }),
    ] }),
    single('offtake', 'Offtake L3 ▸', h.accessor('offtakeL3', { id: 'offtakeL3', header: 'Offtake L3' })),
    single('retail', 'Retail L3 ▸', h.accessor('retailL3', { id: 'retailL3', header: 'Retail L3' })),
    h.group({ id: 'indent', header: `Your indent · ${monthLabel}`, columns: WEEKS.map((w, i) => h.display({
      id: w, header: w,
      cell: ({ row }) => (
        <EditableNumberCell value={row.original.weeks[i] ?? 0} previous={row.original.previousWeeks[i]}
          label={`${w} for ${row.original.description}`} row={row.index} col={i} onCommit={(v) => onChangeWeek(row.original.id, i, v)} />
      ),
    })) }),
  ], [monthLabel, onChangeWeek]);

  const table = useReactTable({
    data: lines, columns, getRowId: (r) => r.id,
    getCoreRowModel: getCoreRowModel(), getFilteredRowModel: getFilteredRowModel(),
    state: { globalFilter: search }, onGlobalFilterChange: setSearch,
    globalFilterFn: (row, _id, f: string) => `${row.original.description} ${row.original.fertCode}`.toLowerCase().includes(f.toLowerCase()),
    initialState: { columnPinning: { left: ['description'] } },
  });
  const visible = table.getRowModel().rows.length;

  return (
    <DataGrid
      table={table}
      label="Indent plan"
      density={density}
      toolbar={(
        <div className="flex flex-wrap items-center gap-3 px-6 py-3">
          <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search code or description"
            aria-label="Search code or description" className="w-72 rounded-control border border-border-strong px-3 py-2 text-body-sm" />
          <span className="inline-flex items-center gap-1.5 rounded-full bg-primary-soft px-3 py-1 text-label text-primary">
            LMD <Button variant="ghost" size="sm" aria-label="Remove LMD">×</Button>
          </span>
          <Button variant="ghost" size="sm" onClick={() => setSearch('')}>Clear all</Button>
          <span className="text-body-sm text-fg-muted"><strong className="text-fg">{visible}</strong> of {lines.length} lines</span>
          <Button variant="outline" size="sm">+ Add FERT</Button>
          <Button variant="ghost" size="sm">Export</Button>
          <DensityToggle value={density} onChange={setDensity} />
          <ColumnsMenu table={table} hideable={[{ id: 'fertCode', label: 'FERT code' }, { id: 'mpg', label: 'MPG' }, { id: 'livePos', label: 'Live POs' }]} />
        </div>
      )}
      footer={(
        <div className="flex items-center justify-end gap-4 px-6 py-3 text-label text-fg-muted">
          <span role="status">Saved just now</span>
          <Button size="sm">Review &amp; submit</Button>
        </div>
      )}
    />
  );
}
