import { useCallback, useState } from 'react';
import { describe, expect, it } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { IndentPlanGrid, type IndentLine } from './IndentPlanGrid';

const seed: IndentLine[] = [
  { id: '1', description: 'H HSD 20FT BSVI NGB', fertCode: 'V4130CAF', mpg: 'Pro 2110', stock: 8, stockTone: 'low', livePos: 1, pipeline: { confirmed: 34, fa: 29, fc: 21, hotInq: 103 }, offtakeL3: 84, retailL3: 35, weeks: [24, 23, 23, 25], previousWeeks: [25, 24, 23, 25] },
  { id: '2', description: 'L CBC 22FT BSVI NGB', fertCode: 'V4030DZL', mpg: 'Pro 2110', stock: 17, stockTone: 'ok', livePos: null, pipeline: { confirmed: 28, fa: 25, fc: 18, hotInq: 87 }, offtakeL3: 71, retailL3: 30, weeks: [19, 18, 18, 20], previousWeeks: [20, 19, 18, 20] },
  { id: '3', description: 'M SLP 24FT BSVI NGB', fertCode: 'V4131SLP', mpg: 'Pro 2110', stock: 4, stockTone: 'warn', livePos: 2, pipeline: { confirmed: 15, fa: 13, fc: 10, hotInq: 47 }, offtakeL3: 38, retailL3: 16, weeks: [10, 10, 9, 9], previousWeeks: [10, 10, 9, 9] },
];
function Harness() {
  const [lines, setLines] = useState(seed);
  const onChangeWeek = useCallback((id: string, week: number, value: number) =>
    setLines((ls) => ls.map((l) => (l.id === id ? { ...l, weeks: l.weeks.map((v, i) => (i === week ? value : v)) } : l))), []);
  return <IndentPlanGrid lines={lines} monthLabel="July 2026" onChangeWeek={onChangeWeek} />;
}

describe('IndentPlanGrid', () => {
  it('uses the exact column labels and order from the design spec', () => {
    render(<Harness />);
    const headers = within(screen.getByRole('table')).getAllByRole('columnheader').map((th) => th.textContent);
    expect(headers.slice(-15)).toEqual(['Description', 'FERT code', 'MPG', 'Stock', 'Live POs', 'Confirmed', 'FA', 'FC', 'Hot Inq', 'Offtake L3', 'Retail L3', 'W1', 'W2', 'W3', 'W4']);
  });

  it('groups the pipeline and indent columns', () => {
    render(<Harness />);
    expect(screen.getByRole('columnheader', { name: 'Pipeline ▸' })).toHaveAttribute('colspan', '4');
    expect(screen.getByRole('columnheader', { name: 'Your indent · July 2026' })).toHaveAttribute('colspan', '4');
  });

  it('freezes the description column and offers details', () => {
    render(<Harness />);
    expect(screen.getByRole('rowheader', { name: /H HSD 20FT BSVI NGB/ })).toHaveClass('sticky', 'left-0');
    expect(screen.getByRole('button', { name: 'Details for H HSD 20FT BSVI NGB' })).toBeInTheDocument();
  });

  it('applies the display rules: stock tone and dash for empty live POs', () => {
    render(<Harness />);
    expect(screen.getByText('8')).toHaveClass('text-danger');
    expect(screen.getByText('4')).toHaveClass('text-warning');
    const row2 = screen.getByRole('rowheader', { name: /L CBC 22FT/ }).closest('tr');
    expect(row2 && within(row2).getByText('–')).toBeInTheDocument();
  });

  it('switches density with the segmented control', async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const compact = screen.getByRole('radio', { name: 'Compact' });
    await user.click(compact);
    expect(compact).toHaveAttribute('data-state', 'on');
    expect(screen.getByRole('rowheader', { name: /H HSD/ })).toHaveClass('py-1');
  });

  it('hides a column from the Columns menu', async () => {
    const user = userEvent.setup();
    render(<Harness />);
    screen.getByRole('button', { name: /Columns/ }).focus();
    await user.keyboard('{Enter}');
    await user.click(await screen.findByRole('menuitemcheckbox', { name: /MPG/ }));
    await user.keyboard('{Escape}'); // the menu stays open for several picks; Esc closes it
    expect(within(screen.getByRole('table')).queryByRole('columnheader', { name: 'MPG' })).not.toBeInTheDocument();
  });

  it('commits an edit with Enter and moves down a row', async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const w1 = screen.getByRole('textbox', { name: 'W1 for H HSD 20FT BSVI NGB' });
    expect(w1).toHaveAccessibleDescription('was 25');
    await user.clear(w1);
    await user.type(w1, '30{Enter}');
    expect(screen.getByRole('textbox', { name: 'W1 for L CBC 22FT BSVI NGB' })).toHaveFocus();
    expect(w1).toHaveValue('30');
  });

  it('filters rows with search', async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(screen.getByRole('searchbox', { name: 'Search code or description' }), 'V4131');
    expect(within(screen.getByRole('table')).getAllByRole('rowheader')).toHaveLength(1);
  });
});
