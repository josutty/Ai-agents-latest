export interface AppHeaderProps {
  dealerName: string;
  initials: string;
}

export function AppHeader({ dealerName, initials }: AppHeaderProps) {
  return (
    <header className="flex items-center justify-end gap-2 bg-inverse px-6 py-2 text-label text-surface">
      <span aria-hidden="true" className="grid size-7 place-items-center rounded-full bg-inverse-muted text-micro">{initials}</span>
      <span>{dealerName}</span>
    </header>
  );
}
