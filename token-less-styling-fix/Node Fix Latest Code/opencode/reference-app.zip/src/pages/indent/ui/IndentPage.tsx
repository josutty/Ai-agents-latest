import { useCallback, useState } from 'react';
import { AppHeader } from '@widgets/app-header';
import { IndentPlanGrid, type IndentLine } from '@widgets/indent-plan';

const seed: IndentLine[] = [
  { id: '1', description: 'H HSD 20FT BSVI NGB', fertCode: 'V4130CAF', mpg: 'Pro 2110', stock: 8, stockTone: 'low', livePos: 1, pipeline: { confirmed: 34, fa: 29, fc: 21, hotInq: 103 }, offtakeL3: 84, retailL3: 35, weeks: [24, 23, 23, 25], previousWeeks: [25, 24, 23, 25] },
  { id: '2', description: 'L CBC 22FT BSVI NGB', fertCode: 'V4030DZL', mpg: 'Pro 2110', stock: 17, stockTone: 'ok', livePos: null, pipeline: { confirmed: 28, fa: 25, fc: 18, hotInq: 87 }, offtakeL3: 71, retailL3: 30, weeks: [19, 18, 18, 20], previousWeeks: [20, 19, 18, 20] },
  { id: '3', description: 'M SLP 24FT BSVI NGB', fertCode: 'V4131SLP', mpg: 'Pro 2110', stock: 4, stockTone: 'warn', livePos: 2, pipeline: { confirmed: 15, fa: 13, fc: 10, hotInq: 47 }, offtakeL3: 38, retailL3: 16, weeks: [10, 10, 9, 9], previousWeeks: [10, 10, 9, 9] },
];

export function IndentPage() {
  const [lines, setLines] = useState(seed);
  const onChangeWeek = useCallback((id: string, week: number, value: number) =>
    setLines((ls) => ls.map((l) => (l.id === id ? { ...l, weeks: l.weeks.map((v, i) => (i === week ? value : v)) } : l))), []);
  return (
    <>
    <AppHeader dealerName="Sharma Motors" initials="SM" />
    <main className="py-4">
      <IndentPlanGrid lines={lines} monthLabel="July 2026" onChangeWeek={onChangeWeek} />
    </main>
    </>
  );
}
