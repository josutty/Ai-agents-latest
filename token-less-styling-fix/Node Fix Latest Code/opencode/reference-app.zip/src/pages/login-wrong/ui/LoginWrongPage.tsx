/** Reproduces the pilot's mistakes: white page, logo inside the card, error instead of the cycle banner, centered link, other blue. */
export function LoginWrongPage() {
  return (
    <main className="flex min-h-screen justify-center bg-surface px-4 py-12">
      <form noValidate onSubmit={(e) => e.preventDefault()} className="h-fit w-96 rounded-card border border-border bg-surface p-8">
        <p className="text-body font-semibold text-fg">RE</p>
        <div role="alert" className="my-3 flex items-center justify-between rounded-control border border-border px-3 py-2 text-body-sm text-danger">
          Request failed <button type="button" className="text-accent">Retry</button>
        </div>
        <h1 className="mb-1 text-heading-3 text-fg">Sign in</h1>
        <p className="mb-4 text-body-sm text-fg">Dealer code or work email.</p>
        <label htmlFor="w-id" className="mb-1.5 block text-body-sm text-fg">Dealer code or email</label>
        <input id="w-id" className="mb-4 w-full rounded-control border border-border-strong bg-surface px-3 py-2.5 text-body-sm" />
        <label htmlFor="w-pw" className="mb-1.5 block text-body-sm text-fg">Password</label>
        <input id="w-pw" type="password" className="w-full rounded-control border border-border-strong bg-surface px-3 py-2.5 text-body-sm" />
        <p className="mt-2 text-center"><a href="#forgot" className="text-label text-accent">Forgot password?</a></p>
        <button type="submit" className="mt-3 w-full rounded-control bg-accent py-2.5 text-body font-semibold text-primary-fg">Sign in</button>
        <p className="my-3 text-center text-label text-fg-muted">or</p>
        <button type="button" className="w-full rounded-control border border-border bg-surface py-2.5 text-body-sm text-fg">Sign in with Royal Enfield SSO</button>
        <p className="mt-4 text-center text-caption text-fg-muted">Trouble signing in? Contact Sales Planning support</p>
        <p className="mt-3 text-center text-caption text-fg-muted">Prototype · your role and verticals come from your account</p>
      </form>
    </main>
  );
}
