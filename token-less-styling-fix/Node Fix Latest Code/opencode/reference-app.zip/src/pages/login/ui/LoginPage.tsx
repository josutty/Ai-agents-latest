/** Built from analysis/design-spec/dealer-login.md — labels, placement and tokens as measured. */
export function LoginPage() {
  return (
    <main className="flex min-h-screen flex-col items-center bg-inverse px-4 py-12">
      <p className="mb-3 text-heading-2 font-bold text-surface">RE</p>
      <p className="mb-5 rounded-control border border-inverse-muted bg-surface/10 px-3 py-1.5 text-label text-surface">S&amp;OP-1A Jul 2026 · Indent closes 15 Jul, 23:59 IST</p>
      <form noValidate onSubmit={(e) => e.preventDefault()} className="w-96 rounded-card bg-surface p-8">
        <h1 className="mb-1 text-heading-2 text-fg">Sign in</h1>
        <p className="mb-6 text-body-sm text-fg-muted">Dealer code or work email.</p>
        <div className="mb-4">
          <label htmlFor="login-id" className="mb-1.5 block text-label font-semibold text-inverse-muted">Dealer code or email</label>
          <input id="login-id" autoComplete="username" className="w-full rounded-control border border-border bg-surface-muted px-3 py-2.5 text-body-sm" />
        </div>
        <div className="mb-4">
          <div className="mb-1.5 flex items-baseline justify-between">
            <label htmlFor="login-pw" className="text-label font-semibold text-inverse-muted">Password</label>
            <a href="#forgot" className="text-label text-accent">Forgot password?</a>
          </div>
          <input id="login-pw" type="password" autoComplete="current-password" className="w-full rounded-control border border-border bg-surface-muted px-3 py-2.5 text-body-sm" />
        </div>
        <button type="submit" className="w-full rounded-control bg-primary py-2.5 text-body font-semibold leading-tight text-primary-fg">Sign in</button>
        <div className="my-4 flex items-center gap-2 text-label text-fg-muted before:flex-1 before:border-t before:border-border before:content-[''] after:flex-1 after:border-t after:border-border after:content-['']">or</div>
        <button type="button" className="w-full rounded-control border border-border bg-surface py-2.5 text-body-sm text-fg">Sign in with Royal Enfield SSO</button>
        <p className="mt-5 text-center text-caption text-fg-muted">Trouble signing in? Contact Sales Planning support</p>
      </form>
      <p className="mt-6 text-caption text-surface">Prototype · your role and verticals come from your account</p>
    </main>
  );
}
