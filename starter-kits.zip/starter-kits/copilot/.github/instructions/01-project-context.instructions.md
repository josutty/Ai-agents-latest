---
description: Fill project name, modules, and glossary after install
applyTo: "**"
---

# Project Context

- Read `.github/config.yaml` for module roots, harness paths, and quality gates.
- Do not assume a vendor, warehouse, or optical domain.
- If `config.yaml` still contains placeholders (`<project-name>`), stop and ask the user to fill it before generating product code.
