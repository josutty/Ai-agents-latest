#!/usr/bin/env node
// Self-test on YOUR data: rebuild a "before" version of an already-finished config by undoing the audit changes,
// apply the change list to it, and compare the result with the finished file.
//   node selftest.mjs --finished classic-350.json --changes out/change-list.json --bike J1A [--mapping mapping.nec-uk.json]
import { readFileSync, writeFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { ConfigDoc } from './lib/doc.mjs';
import { applyChange, checkChange, makeContext, variants } from './lib/changes.mjs';
import { clone, keys, get } from './lib/ordered-json.mjs';
import { parseArgs, need } from './lib/cli.mjs';

const a = parseArgs(process.argv.slice(2)); const text = readFileSync(need(a, 'finished'), 'utf8');
const list = JSON.parse(readFileSync(need(a, 'changes'), 'utf8')); const bike = list.bikes.find((b) => b.code === need(a, 'bike'));
const mapping = a.mapping ? JSON.parse(readFileSync(a.mapping, 'utf8')) : {};
// 1. undo the changes -> "before"
const d0 = new ConfigDoc(text); const undone = [];
for (const ch of bike.changes.filter((c) => c.decision === 'apply')) {
  if (ch.action === 'add') for (const k of (ch.pair ? [`${ch.part}-R`, `${ch.part}-P`] : [ch.part])) { if (d0.has('parts', k)) { d0.remove('parts', k); undone.push(`un-add ${k}`); } }
  if (ch.action === 'remove' && !variants(d0, 'parts', ch.part).length) for (const k of variants(d0, 'inActiveParts', ch.part)) { d0.insertValue('parts', k, clone(d0.get('inActiveParts', k))); d0.remove('inActiveParts', k); undone.push(`un-remove ${k}`); }
  if (ch.action === 'price') for (const k of variants(d0, 'parts', ch.part)) for (const c of keys(d0.get('parts', k).price)) if (d0.get('parts', k).price[c] !== String(Math.round(ch.price.from))) d0.setPrice('parts', k, c, String(Math.round(ch.price.from)));
}
const before = d0.render(); const dir = mkdtempSync(join(tmpdir(), 'rt-')); writeFileSync(join(dir, 'before.json'), before);
console.log(`1. rebuilt a "before" file by undoing ${undone.length} changes (${undone.slice(0, 4).join(', ')}…)`);
// 2. apply the change list
const d1 = new ConfigDoc(before); const ctx = makeContext(d1, { subCategoryMap: mapping.subCategoryMap ?? {} });
const res = bike.changes.map((ch) => ({ ch, r: applyChange(d1, ch, ctx) })); const after = d1.render();
const n = (s) => res.filter((x) => x.r.status === s).length;
console.log(`2. applied: ${n('applied')} applied · ${n('already-done')} already done · ${n('not-in-config')} not in config · ${n('skipped')} skipped · ${n('cannot-apply')} cannot apply`);
// 3. compare with the finished file
const fin = new ConfigDoc(text); const out = new ConfigDoc(after);
const secs = ['parts', 'inActiveParts']; let sameParts = 0; const diffs = [];
for (const s of secs) {
  const fk = new Set(fin.keys(s)); const ok = new Set(out.keys(s));
  for (const k of fk) if (!ok.has(k)) diffs.push(`${s}: ${k} is in the finished file but not in the result`);
  for (const k of ok) if (!fk.has(k)) diffs.push(`${s}: ${k} is in the result but not in the finished file`);
  for (const k of ok) if (fk.has(k)) { const A = JSON.stringify(out.get(s, k)), B = JSON.stringify(fin.get(s, k)); if (A === B || JSON.stringify(sortKeys(out.get(s, k))) === JSON.stringify(sortKeys(fin.get(s, k)))) sameParts++; else { const fa = out.get(s, k), fb = fin.get(s, k); const f = [...new Set([...Object.keys(fa), ...Object.keys(fb)])].filter((x) => JSON.stringify(fa[x]) !== JSON.stringify(fb[x])); diffs.push(`${s}: ${k} differs in ${f.join(', ')}`); } }
}
function sortKeys(o) { return o && typeof o === 'object' && !Array.isArray(o) ? Object.fromEntries(Object.keys(o).sort().map((k) => [k, sortKeys(o[k])])) : Array.isArray(o) ? o.map(sortKeys) : o; }
const other = Object.keys(fin.root).filter((k) => !secs.includes(k.replace(/^\u0000/, '')) && JSON.stringify(fin.root[k]) !== JSON.stringify(out.root[k]));
console.log(`3. compared with the finished file: ${sameParts} entries identical, ${diffs.length} difference(s); other top-level keys changed: ${other.length}`);
for (const x of diffs) console.log('   -', x);
const chk = bike.changes.map((ch) => checkChange(out, ch)); console.log(`4. check on the result: ✔ ${chk.filter((c) => c.state === 'ok').length} done · ✘ ${chk.filter((c) => c.state === 'todo').length} to do`);
// 5. text-level proof that only touched entries changed
const bl = before.split('\r\n'), al = after.split('\r\n'); writeFileSync(join(dir, 'after.json'), after); console.log(`   files written to ${dir}`);
console.log(`5. line count before ${bl.length} -> after ${al.length}; untouched lines at the start: ${(() => { let i = 0; while (bl[i] === al[i]) i++; return i; })()}`);
