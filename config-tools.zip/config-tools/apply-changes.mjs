#!/usr/bin/env node
// Apply a change list to ONE bike's config JSON. Never overwrites the input: writes a patched copy + a report.
//   node apply-changes.mjs --config classic-350.json --changes change-list.json --bike J1A [--out classic-350.patched.json] [--include-ask]
import { readFileSync, writeFileSync } from 'node:fs';
import { ConfigDoc } from './lib/doc.mjs';
import { applyChange, baseOf, contextFor, priceVariantReminders } from './lib/changes.mjs';
import { parseArgs, need, cut, mdRow } from './lib/cli.mjs';

const a = parseArgs(process.argv.slice(2));
const cfgPath = need(a, 'config'); const list = JSON.parse(readFileSync(need(a, 'changes'), 'utf8')); const bike = list.bikes.find((b) => b.code === need(a, 'bike', '(e.g. J1A)'));
if (!bike) { console.error(`✘ bike ${a.bike} is not in the change list (has: ${list.bikes.map((b) => b.code).join(', ')})`); process.exit(2); }
const mapping = a.mapping ? JSON.parse(readFileSync(a.mapping, 'utf8')) : {};
const doc = new ConfigDoc(readFileSync(cfgPath, 'utf8')); const ctx = contextFor(doc, bike, mapping); if (a['thumb-dir']) ctx.thumbDir = a['thumb-dir'];
const order = { remove: 0, price: 1, rename: 2, image: 3, add: 4, review: 5 };   // removals first: a part removed and restored in one run must land in inActiveParts before it is restored
const results = [...bike.changes].sort((x, y) => order[x.action] - order[y.action]).map((ch) => ({ ch, r: applyChange(doc, a['include-ask'] ? { ...ch, decision: ch.decision === 'ask' ? 'apply' : ch.decision } : ch, ctx) }));
// parts moved to inActiveParts that active parts still point at (productToAdd / productToRemove) would leave a dangling reference
const moved = results.filter(({ ch, r }) => ch.action === 'remove' && r.status === 'applied').map(({ ch }) => ch.part); const dangling = [];
for (const k of doc.keys('parts')) { const part = doc.get('parts', k); for (const f of ['productToAdd', 'productToRemove']) for (const e of Array.isArray(part[f]) ? part[f] : []) { const it = String(e?.item ?? e); if (moved.includes(baseOf(it))) dangling.push(`${k}.${f} -> ${it}`); } }
const out = doc.render();
const outPath = a.out ?? cfgPath.replace(/\.json$/i, '') + '.patched.json'; writeFileSync(outPath, out);
const c = (s) => results.filter((x) => x.r.status === s).length;
const lines = [`# Apply report — ${bike.code} (${cfgPath})`, '', `Output: ${outPath} — input file was NOT modified. Only the touched entries changed; all other text, indentation and line endings are byte-identical.`, '',
  `applied ${c('applied')} · already done ${c('already-done')} · not in config ${c('not-in-config')} · skipped ${c('skipped')} · unresolved ${c('unresolved')} · cannot apply ${c('cannot-apply')}`, '',
  '| Part | Action | Result | Detail |', '|---|---|---|---|', ...results.map(({ ch, r }) => mdRow([ch.part, ch.action, r.status, cut(r.detail, 110)]))];
const todo = results.flatMap(({ r }) => r.notes);
lines.push('', `## Notes and reminders for a person (${todo.length})`, '', ...(todo.length ? todo.map((n) => `- ${n}`) : ['Nothing.']));
lines.push('', `## Check: active parts that still reference a part you moved to inActiveParts (${dangling.length})`, '', ...(dangling.length ? dangling.map((d) => `- ${d}`) : ['None.']));
const rem = priceVariantReminders(doc, ctx); lines.push('', `## Reminder: price objects missing a standard colour (${rem.length} part${rem.length === 1 ? '' : 's'})`, '', ...(rem.length ? rem.slice(0, 40).map(([k, miss]) => `- ${k}: ${miss.join(', ')}`) : ['None — every part has all colorWiseStandardPartsMapping colours.']));
const rp = a.report ?? outPath.replace(/\.json$/i, '') + '.report.md'; writeFileSync(rp, lines.join('\n') + '\n');
console.log(`✔ ${bike.code}: applied ${c('applied')} · already done ${c('already-done')} · not in config ${c('not-in-config')} · skipped ${c('skipped')} · unresolved ${c('unresolved')} · cannot apply ${c('cannot-apply')}`);
if (dangling.length) console.log(`  ⚠ ${dangling.length} active part reference(s) point at a part that is now inactive — see the report (e.g. ${dangling.slice(0, 2).join('; ')})`);
console.log(`  patched copy → ${outPath}\n  report       → ${rp}${todo.length ? `   (${todo.length} note(s) for a person: please skim — price variants, 3D position, image…)` : ''}`);
