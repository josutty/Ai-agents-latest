#!/usr/bin/env node
// Apply a change list to ONE bike's config JSON. Never overwrites the input: writes a patched copy + a report.
//   node apply-changes.mjs --config classic-350.json --changes change-list.json --bike J1A [--out classic-350.patched.json] [--include-ask]
import { readFileSync, writeFileSync } from 'node:fs';
import { ConfigDoc } from './lib/doc.mjs';
import { applyChange, makeContext } from './lib/changes.mjs';
import { parseArgs, need, cut, mdRow } from './lib/cli.mjs';

const a = parseArgs(process.argv.slice(2));
const cfgPath = need(a, 'config'); const list = JSON.parse(readFileSync(need(a, 'changes'), 'utf8')); const bike = list.bikes.find((b) => b.code === need(a, 'bike', '(e.g. J1A)'));
if (!bike) { console.error(`✘ bike ${a.bike} is not in the change list (has: ${list.bikes.map((b) => b.code).join(', ')})`); process.exit(2); }
const mapping = a.mapping ? JSON.parse(readFileSync(a.mapping, 'utf8')) : {};
const doc = new ConfigDoc(readFileSync(cfgPath, 'utf8')); const ctx = makeContext(doc, { subCategoryMap: mapping.subCategoryMap ?? {}, thumbBase: a['thumb-base'] });
const order = { remove: 0, price: 1, add: 2, review: 3 };
const results = [...bike.changes].sort((x, y) => order[x.action] - order[y.action]).map((ch) => ({ ch, r: applyChange(doc, a['include-ask'] ? { ...ch, decision: ch.decision === 'ask' ? 'apply' : ch.decision } : ch, ctx) }));
const out = doc.render();
const outPath = a.out ?? cfgPath.replace(/\.json$/i, '') + '.patched.json'; writeFileSync(outPath, out);
const c = (s) => results.filter((x) => x.r.status === s).length;
const lines = [`# Apply report — ${bike.code} (${cfgPath})`, '', `Output: ${outPath} — input file was NOT modified. Only the touched entries changed; all other text, indentation and line endings are byte-identical.`, '',
  `applied ${c('applied')} · already done ${c('already-done')} · not in config ${c('not-in-config')} · skipped ${c('skipped')} · unresolved ${c('unresolved')} · cannot apply ${c('cannot-apply')}`, '',
  '| Part | Action | Result | Detail |', '|---|---|---|---|', ...results.map(({ ch, r }) => mdRow([ch.part, ch.action, r.status, cut(r.detail, 110)]))];
const todo = results.flatMap(({ r }) => r.notes);
lines.push('', `## Needs a person (${todo.length})`, '', ...(todo.length ? todo.map((n) => `- ${n}`) : ['Nothing.']));
const rp = a.report ?? outPath.replace(/\.json$/i, '') + '.report.md'; writeFileSync(rp, lines.join('\n') + '\n');
console.log(`✔ ${bike.code}: applied ${c('applied')} · already done ${c('already-done')} · not in config ${c('not-in-config')} · skipped ${c('skipped')} · unresolved ${c('unresolved')} · cannot apply ${c('cannot-apply')}`);
console.log(`  patched copy → ${outPath}\n  report       → ${rp}${todo.length ? `   (${todo.length} item(s) need a person: order / thumbnail / 3D position…)` : ''}`);
