# config-tools — Excel audit → change list → patched bike config

Turns an audit spreadsheet into a list of changes and applies them to a bike's config JSON (`parts` / `inActiveParts`).
**It reads Excel and config files only, and writes a patched COPY.** It never connects to Firestore or Azure and needs no credentials.
Scripts decide *how* to apply (repeatable, diff-able); a person (or the prompt in `prompts/config-intake.md`) decides *what* when a sheet is unclear.

## Setup (once)
```
cd tools/config        # or wherever you copy this folder
npm install            # only dependency: xlsx (reads Excel). Node 20+.
npm test               # 7 tests, made-up data only
```
`xlsx` from npm is v0.18.5 and has published advisories for *malicious* workbooks. Use it on your own company files only; for a file from
an unknown source, export CSV first.

## The flow
```
1  node read-audit.mjs  --audit <audit.xlsx> --master <master.xlsx> --mapping mapping.nec-uk.json --decisions decisions.json --out out/change-list.json --questions out/questions.md
   -> read out/questions.md; answer anything under "Needs your answer" in decisions.json (overrides), run step 1 again
2  node apply-changes.mjs --config <bike>.json --changes out/change-list.json --bike J1A --mapping mapping.nec-uk.json
   -> <bike>.patched.json + <bike>.patched.report.md   (diff the patched copy against the original, then put it where it belongs)
3  node check-config.mjs  --config <bike>.patched.json --changes out/change-list.json --bike J1A
   -> is every audit correction reflected?  exit code 1 if something is still to do   (also works on a finished file)
```
`node inspect-xlsx.mjs <file> [--sheet name] [--rows 8]` shows a workbook's layout without reading it all.

## The rules (learned from the hand-finished Classic 350 file)
| Audit says | What happens |
|---|---|
| `REMOVE` | the part leaves `parts` and is in `inActiveParts` (object moved unchanged; an existing inactive entry is kept; not in the config = nothing to do). Rider/pillion variants `-R`/`-P` move together |
| `MISSING` | added to `parts`: restored from `inActiveParts` if it is there, else built from the master sheet. Footpegs (and any part listed twice) become `<pn>-R` / `<pn>-P` |
| a number ≠ GB-PRICE | every colour's price becomes the whole-number string (`25.565` → `"26"`); a part not in `parts` (e.g. a combined set key) is skipped |
| blank, with a not-UK/obsolete note | **not acted on** (listed as `review`) |

A built part gets from the master: `category`, `subCategory` (mapped, e.g. Luggage → Panniers), `productName`, `displayName`, `price`, `collisionProduct`,
and from the part number: `gmapartnumber`, `productId`, `modelPartId` (`<pn>:ON`), `tripperPartIdRemove` (`<pn>:OFF`). "Not shown in 3D" in the master notes →
`isNonThreeD`, empty ids. **Not in the master — the report lists them for a person:** `order` (proposed), `thumbnailImage` (pattern proposed),
`threeDPos`, and `productToAdd` / `productToRemove` when the master lists essentials.

## Decisions
`decisions.json` holds precedent *rules* (first match wins) and per-row *overrides* (`"J1A|KXA00121|add"`). Each decision is `apply`, `skip` or `ask`;
`ask` rows are not applied until you answer. Current rules: add even when notes say Not UK; skip set-priced seat rows and price changes where the
configurator price is 0; skip `review` rows; ask when a MISSING part is not in the master. **Every precedent came from one bike (Classic 350)** — skim
the "Applied by a precedent rule" list in `questions.md` for the others.

## Change list format (`change-list.json`)
`{ bikes: [ { code, auditSheet, masterSheet, changes: [ { id, part, name, action: remove|add|price|review, price?: {from,to}, master?: {...}, pair?, notes, flags, decision, why } ] } ] }`
Write rows in this shape by hand (or via the prompt) when a requirement is plain text.

## A different Excel layout
Copy `mapping.nec-uk.json` to `mapping.<name>.json` and change the column letters, `actionWords`, `flags` and the `bikes` sheet pairing. No code change.
`prompts/config-intake.md` does this with an AI chat and a few sample rows.

## Guarantees and limits
- **Surgical edits:** only the touched entries change. Indentation, CRLF line endings and key order (including keys like `1990218`) stay byte-identical;
  an edit that changes nothing leaves the file identical. The tool re-parses its own output and refuses to write if it differs from the intent.
- Tested on the real Classic 350 (audit + master + finished file): the 3 removals and 3 price changes are reproduced exactly; the 17 added parts match
  except the fields listed above. **Not tested:** the other 14 bikes' configs (no finished files to compare), Windows paths, very large workbooks (the master is read one sheet at a time).
- `selftest.mjs --finished <done.json> --changes out/change-list.json --bike J1A` re-runs that comparison on any finished config you have.
- Formula cells are read by their **cached value** (the audit's column D is a Google-Sheets formula). If a sheet was never recalculated, the values may be stale.
