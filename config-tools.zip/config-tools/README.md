# config-tools — Excel audit → change list → patched bike config

Turns an audit spreadsheet into a list of changes and applies them to a bike's config JSON (`parts` / `inActiveParts`).
**It reads Excel and config files only, and writes a patched COPY.** It never connects to Firestore or Azure and needs no credentials.
Scripts decide *how* to apply (repeatable, diff-able); a person (or `prompts/config-intake.md`) decides *what* when a sheet is unclear.

## Setup (once)
```
cd tools/config
npm install            # only dependency: xlsx (reads Excel). Node 20+.
npm test               # 11 tests, made-up data only
```
`xlsx` from npm is v0.18.5 and has published advisories for *malicious* workbooks: use it on your own company files only.

## The flow
```
1  node read-audit.mjs  --audit <audit.xlsx> --master <master.xlsx> --mapping mapping.nec-uk.json --decisions decisions.json --out out/change-list.json --questions out/questions.md
2  node apply-changes.mjs --config <bike>.json --changes out/change-list.json --bike J1A --mapping mapping.nec-uk.json
   -> <bike>.patched.json + <bike>.patched.report.md  (diff the copy against the original, fill in what the report asks, then publish it your usual way)
3  node check-config.mjs  --config <bike>.patched.json --changes out/change-list.json --bike J1A --mapping mapping.nec-uk.json
   -> is every audit correction reflected? exit code 1 if something is still to do (also works on a finished file)
```
`node inspect-xlsx.mjs <file> [--sheet name] [--rows 8]` shows a workbook's layout. Optional: `--thumb-dir <url folder/>` on `apply-changes` overrides the image folder.

## The rules (owner's answers + the hand-finished Classic 350)
| Audit says | What happens |
|---|---|
| `REMOVE` | the part leaves `parts` and lives in `inActiveParts` (object moved unchanged; an existing inactive entry is kept). Not in the config = nothing to do. `-R`/`-P` variants move together |
| `MISSING`, notes say **not UK / obsolete / NLA / not available** | **not added**: treated as a remove (moved to `inActiveParts` if it is there) |
| no action marked, notes say not UK / obsolete | treated as a remove, the same way |
| `MISSING` otherwise | added to `parts` (see "A new part"). Footpegs, and any part listed twice, become `<pn>-R` / `<pn>-P` |
| a number ≠ the master price | every colour's price becomes the whole-number string of the **master** price (audit price if the master has none: flagged `auditPrice`). Not in `parts` = skipped |
| note "Update name" | `productName` and `displayName` are set from the master |
| note "Update image …" | `thumbnailImage` follows the other accessory parts (below). A `.jpg` note still becomes `<PN>_400.png`; a `…_400.png` name is used as written |
| set-priced rows (note "Rider and Pillion shown as set", or configurator price 0) | left unchanged (the combined set key, e.g. KXA0006971, carries the price) |

**A new part** is built from the master sheet and the other parts:
`category`, `subCategory` (mapped, e.g. Luggage → Panniers), `productName`, `displayName` (always), `price` (every colour in `colorWiseStandardPartsMapping`),
`order` (highest `order` in the same category + sub-category, plus 1; pairs consecutive), `threeDPos` (copied from a part of the same type, otherwise zeros; none for "not shown in 3D" parts),
`thumbnailImage` (folder most used by other accessory parts for `_400.png` images — not the tank/colour entries), `productToAdd` / `productToRemove` / `collisionProduct`
(from the master columns, `ALL_COLORS`, only parts that exist for this bike, rider/pillion pairs expanded to `-R`/`-P`; when the master lists nothing to remove but something to add,
`productToRemove` mirrors `productToAdd` — switch off with `build.mirrorRemove: false` in the mapping).
**A part found in `inActiveParts` is restored**, then refreshed from the master the same way (names, category, price, image, the three lists); its `order` and `threeDPos` are kept.
Every report line says what was set and from where. **Reminder (always printed):** check each new/restored part's price object variants against `colorWiseStandardPartsMapping`.

## Decisions
`decisions.json`: precedent *rules* (first match wins) and per-row *overrides* (`"J1A|KXA00121|remove"`). `apply`, `skip` or `ask`; `ask` rows are not applied until you answer.
`questions.md` lists what needs an answer, what was applied by a precedent, and what was not acted on.

## What to read in the report
- **Notes and reminders:** order rule used, where `threeDPos` came from, image path, parts left out of the lists because they don't exist for this bike.
- **Check: active parts that still reference a part you moved to inActiveParts** — e.g. removing KXA00198 leaves 1990270 / 1990278 / KXA00256 pointing at it.
- **Reminder: price objects missing a standard colour.**

## Change list format
`{ bikes: [ { code, auditSheet, masterSheet, masterParts: [...], changes: [ { id, part, name, action: remove|add|price|rename|image|review, price?: {from,to,source}, master?, image?: {file}, pair?, notes, flags, decision, why } ] } ] }`

## A different Excel layout
Copy `mapping.nec-uk.json` to `mapping.<name>.json` and change the column letters, `actionWords`, `flags` and the `bikes` sheet pairing. No code change. `prompts/config-intake.md` does this with an AI chat.

## Guarantees and limits
- **Surgical edits:** only the touched entries change. Indentation, CRLF line endings and key order (including keys like `1990218`) stay byte-identical; a second run changes nothing.
  The tool re-parses its own output and refuses to write if it differs from the intent.
- Tested on the real Classic 350 (audit + master + finished file). **Not tested:** the other 14 bikes' configs, Windows paths.
- `selftest.mjs --finished <done.json> --changes out/change-list.json --bike J1A --mapping mapping.nec-uk.json` rebuilds a "before" from a finished file, applies the list and compares.
  Differences from a hand-made file are expected where the rules differ (order, price colours, threeDPos, image path).
- Formula cells are read by their **cached value** (the audit's column D is a Google-Sheets formula).
