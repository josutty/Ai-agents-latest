#!/usr/bin/env node
// Excel audit sheets (+ master sheets) -> change-list.json + questions.md. Reads Excel only; never touches a config.
//   node read-audit.mjs --audit <audit.xlsx> --master <master.xlsx> --mapping mapping.nec-uk.json --decisions decisions.json [--bike J1A] [--out change-list.json] [--questions questions.md]
import XLSX from 'xlsx';
import { readFileSync, writeFileSync } from 'node:fs';
import { parseArgs, need, cut, mdRow } from './lib/cli.mjs';

const a = parseArgs(process.argv.slice(2));
const mapping = JSON.parse(readFileSync(need(a, 'mapping'), 'utf8')); const decisions = JSON.parse(readFileSync(need(a, 'decisions'), 'utf8'));
const colNum = (L) => [...L.toUpperCase()].reduce((n, c) => n * 26 + c.charCodeAt(0) - 64, 0);
// SheetJS returns the CACHED value of formula cells (the audit's column D is a Google-Sheets formula; 0 and blank results must survive).
const load = (f, sheets) => XLSX.readFile(f, { cellFormula: false, cellStyles: false, cellHTML: false, sheets });
const rows = (wb, name, startRow, cols) => {
  const ws = wb.Sheets[name]; if (!ws) return null; const r = XLSX.utils.decode_range(ws['!ref']); r.s.r = 0; r.s.c = 0;
  const arr = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null, blankrows: true, range: r });
  return arr.map((row, i) => ({ row, n: i + 1 })).filter((x) => x.n >= startRow).map(({ row, n }) => Object.fromEntries([['_row', n], ...Object.entries(cols).map(([k, L]) => [k, row[colNum(L) - 1] ?? null])]));
};
const re = Object.fromEntries(Object.entries(mapping.flags).map(([k, v]) => [k, new RegExp(v, 'i')]));
const num = (v) => (typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' && Number.isFinite(Number(v)) ? Number(v) : null);

function decide(code, ch) {
  const o = decisions.overrides?.[`${code}|${ch.part}|${ch.action}`]; if (o) return { decision: o.decision, why: o.why ?? '' };
  for (const r of decisions.rules ?? []) { const w = r.when ?? {}; if ((!w.action || w.action === ch.action) && (!w.flag || ch.flags.includes(w.flag))) return { decision: r.decision, why: r.why ?? '' }; }
  return { decision: 'apply', why: '' };
}

const wantBikes = mapping.bikes.filter((b) => !a.bike || b.code === a.bike);
const audit = load(need(a, 'audit', '<audit.xlsx>'), wantBikes.map((b) => b.auditSheet)); const master = load(need(a, 'master', '<master.xlsx>'), wantBikes.map((b) => b.masterSheet).filter(Boolean));
const A = mapping.audit; const M = mapping.master; const out = { meta: { generated: new Date().toISOString(), audit: a.audit, master: a.master, mapping: a.mapping }, bikes: [] };
for (const bike of mapping.bikes) {
  if (a.bike && bike.code !== a.bike) continue;
  const arows0 = rows(audit, bike.auditSheet, A.dataStartRow, A.columns);
  if (!arows0) { console.error(`⚠ audit sheet not found: ${bike.auditSheet}`); continue; }
  const mrows0 = bike.masterSheet ? rows(master, bike.masterSheet, M.dataStartRow, M.columns) : null;
  if (!mrows0) console.error(`⚠ master sheet not found for ${bike.code}: parts to ADD cannot be built`);
  const mrows = mrows0 ? Object.fromEntries(mrows0.filter((r) => r.part).map((r) => [String(r.part).trim(), r])) : {};
  const arows = arows0.filter((r) => r.part || r.name);
  const seen = {}; for (const r of arows) { const p = String(r.part ?? '').trim(); seen[p] = (seen[p] ?? 0) + 1; }
  const changes = []; const dedupe = new Set();
  const masterOf = (m) => ({ retailName: m.retailName, displayName: m.displayName, category: m.category, subCategory: m.subCategory, price: num(m.price) ?? m.price, availability: m.availability, essentialToAdd: m.essentialToAdd, essentialToRemove: m.essentialToRemove, accConflicts: m.accConflicts, oeConflicts: m.oeConflicts, thumbnail: m.thumbnail, notes: m.notes, nonThreeD: re.nonThreeD ? re.nonThreeD.test(String(m.notes ?? '')) : false });
  const push = (ch) => { const key = `${ch.part}|${ch.action}`; if (dedupe.has(key)) return; dedupe.add(key); ch.id = `${bike.code}-${String(changes.length + 1).padStart(4, '0')}`; Object.assign(ch, decide(bike.code, ch)); changes.push(ch); };
  for (const r of arows) {
    const part = String(r.part ?? '').trim(); if (!part) continue;
    const notes = [r.notes, r.ukNotes].filter((x) => x != null && String(x).trim() !== '').map((x) => String(x).trim()).join(' | ');
    const flags = []; const word = typeof r.current === 'string' ? r.current.trim().toUpperCase() : null; const cur = num(r.current); const target = num(r.targetPrice);
    const notUk = re.notUk.test(notes); const m = mrows[part];
    let action = null;
    if (word && A.actionWords[word]) action = A.actionWords[word];
    else if (cur !== null && target !== null && Math.round(cur * 100) !== Math.round(target * 100)) action = 'price';
    else if ((r.current == null || r.current === '') && notUk) { action = 'remove'; flags.push('notUkNoAction'); }          // no action marked, notes say not UK -> remove
    if (action === 'add' && notUk) { action = 'remove'; flags.push('notUkMissing'); }                                       // MISSING but not UK -> do not add; move if present
    const wantsName = re.nameUpdate?.test(notes); const wantsImage = re.imageUpdate?.test(notes); const file = /([A-Za-z0-9]+(?:_\d+)?\.(?:png|jpe?g))/i.exec(notes)?.[1];
    if (!action && !wantsName && !wantsImage) continue;
    if (notUk) flags.push('notUk'); if (re.setPricing.test(notes)) flags.push('setPricing'); if (wantsImage) flags.push('imageUpdate'); if (wantsName) flags.push('nameUpdate'); if (re.rounding.test(notes)) flags.push('rounding');
    if (action === 'price' && cur === 0) flags.push('zeroConfig');
    const base = { part, name: r.name ?? '', notes, sourceRow: r._row };
    if (action) {
      const ch = { ...base, action, flags: [...flags] };
      if (action === 'price') { const mp = m ? num(m.price) : null; ch.price = { from: cur, to: mp ?? target, source: mp !== null ? 'master' : 'audit' }; if (mp === null) ch.flags.push('auditPrice'); }
      if (action === 'add') {
        if (seen[part] > 1 || re.pairName?.test(ch.name)) { ch.pair = true; ch.flags.push('pair'); }
        if (m) ch.master = masterOf(m); else ch.flags.push('notInMaster');
        if (wantsImage) ch.image = { file: file ?? null };
      }
      push(ch);
    }
    if (wantsName && action !== 'remove' && action !== 'add') push({ ...base, action: 'rename', flags: ['nameUpdate'], master: m ? masterOf(m) : null });
    if (wantsImage && action !== 'remove' && action !== 'add') push({ ...base, action: 'image', flags: ['imageUpdate'], image: { file: file ?? null } });
  }
  out.bikes.push({ code: bike.code, auditSheet: bike.auditSheet, masterSheet: bike.masterSheet, config: bike.config ?? null, masterParts: Object.keys(mrows), changes });
}
const all = out.bikes.flatMap((b) => b.changes.map((c) => ({ ...c, code: b.code })));
const count = (f) => all.filter(f).length;
out.summary = { total: all.length, byAction: Object.fromEntries(['remove', 'add', 'price', 'rename', 'image', 'review'].map((x) => [x, count((c) => c.action === x)])), byDecision: Object.fromEntries(['apply', 'skip', 'ask'].map((x) => [x, count((c) => c.decision === x)])) };
writeFileSync(a.out ?? 'change-list.json', JSON.stringify(out, null, 2));
const q = ['# Questions and decisions', '', `Generated ${out.meta.generated}. ${out.summary.total} changes: ${JSON.stringify(out.summary.byAction)} · decisions ${JSON.stringify(out.summary.byDecision)}`, ''];
const ask = all.filter((c) => c.decision === 'ask');
q.push(`## Needs your answer (${ask.length})`, '', ...(ask.length ? ['| Bike | Part | Action | Why it needs you | Notes |', '|---|---|---|---|---|', ...ask.map((c) => mdRow([c.code, c.part, c.action, c.why || c.flags.join(', '), cut(c.notes, 70)]))] : ['Nothing — every row has a decision.']), '');
q.push('Answer by adding `"<bike>|<part>|<action>": { "decision": "apply" | "skip", "why": "…" }` to `overrides` in decisions.json, then run read-audit again.', '');
const prec = all.filter((c) => c.decision === 'apply' && c.flags.some((f) => ['notUk', 'imageUpdate', 'nameUpdate', 'rounding', 'auditPrice'].includes(f)));
q.push(`## Applied by a precedent rule — please skim (${prec.length})`, '', ...(prec.length ? ['| Bike | Part | Action | Flags | Notes |', '|---|---|---|---|---|', ...prec.map((c) => mdRow([c.code, c.part, c.action, c.flags.join(', '), cut(c.notes, 70)]))] : ['None.']), '');
const skipped = all.filter((c) => c.decision === 'skip');
q.push(`## Not acted on (${skipped.length})`, '', ...(skipped.length ? ['| Bike | Part | Action | Reason |', '|---|---|---|---|', ...skipped.map((c) => mdRow([c.code, c.part, c.action, c.why || cut(c.notes, 70)]))] : ['None.']));
writeFileSync(a.questions ?? 'questions.md', q.join('\n') + '\n');
console.log(`✔ ${out.summary.total} changes → ${a.out ?? 'change-list.json'}   (${Object.entries(out.summary.byAction).map(([k, v]) => `${k} ${v}`).join(' · ')})`);
console.log(`  decisions: apply ${out.summary.byDecision.apply} · skip ${out.summary.byDecision.skip} · ask ${out.summary.byDecision.ask}   → questions in ${a.questions ?? 'questions.md'}`);
