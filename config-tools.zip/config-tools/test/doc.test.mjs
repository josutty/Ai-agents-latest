import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ConfigDoc } from '../lib/doc.mjs';
import { applyChange, checkChange, makeContext, priceVariantReminders, roundPrice } from '../lib/changes.mjs';
import { stringifyAt } from '../lib/ordered-json.mjs';

const EOL = '\r\n'; const at = (v) => stringifyAt(v, { base: '        ', step: '  ', eol: EOL });
const POS = { pan1: 1, pan2: 2, xAng: 3, yAng: 4, zoom: 5 };
const part = (pn, over = {}) => ({ category: 'Comfort', collisionProduct: [''], displayName: `D ${pn}`, gmapartnumber: pn, isHelperProduct: '', isHidden: '', modelPartId: `${pn}:ON`, order: 1,
  price: { Red: '36', Blue: '36' }, productId: pn, productName: `N ${pn}`, subCategory: 'Seats', threeDPos: POS, thumbnailImage: `https://h/uk/Accessories/Common/${pn}_400.png`, tripperPartIdRemove: `${pn}:OFF`, ...over });
// integer-like keys + CRLF + odd indentation + colorWiseStandardPartsMapping, like the real files
const build = (parts, inactive) => ` {${EOL}        "categoryOrder": ${at(['Comfort.Seats', 'Comfort.Panniers'])},${EOL}        "colorWiseStandardPartsMapping": ${at({ Red: {}, Blue: {} })},${EOL}        "inActiveParts": ${at(inactive)},${EOL}        "parts": ${at(parts)}${EOL}      }`;
const noDisplay = (pn) => { const p = part(pn); delete p.displayName; return p; };
const fixture = () => build({ 1990218: part('1990218', { category: 'Style', subCategory: 'Oil Filler Cap', order: 44 }), KXA00001: part('KXA00001'), KXA00004: part('KXA00004'), KXA00005: noDisplay('KXA00005'),
  'KXA00002-R': part('KXA00002-R', { subCategory: 'Footpegs' }), 'KXA00002-P': part('KXA00002-P', { subCategory: 'Footpegs', order: 2 }) },
  { KXA00004: part('KXA00004', { price: { Red: '99', Blue: '99' } }), KXA00099: part('KXA00099', { subCategory: 'Mirrors', productName: 'OLD NAME', thumbnailImage: 'https://h/old/KXA00099.png', price: { Red: '1', Blue: '1' }, productToAdd: [{ applicableForColors: ['ALL_COLORS'], item: 'KXA00001' }] }) });
const master = (over = {}) => ({ retailName: 'NEW GRIPS', displayName: 'NEW GRIPS - BROWN', category: 'Comfort', subCategory: 'Seats', price: 25.565, essentialToAdd: 'NA', essentialToRemove: 'NA', accConflicts: 'NA', nonThreeD: false, ...over });
const ctxOf = (d, o = {}) => makeContext(d, { subCategoryMap: { Luggage: 'Panniers' }, masterParts: ['KXA00300', 'KXA00301', 'KXA00181', 'KXA00182'], ...o });
const apply = (d, ctx, ch) => applyChange(d, { decision: 'apply', ...ch }, ctx);

test('an untouched render is byte-identical (CRLF, odd indentation, integer-like keys)', () => { const t = fixture(); assert.equal(new ConfigDoc(t).render(), t); });

test('remove moves the part; every other line stays; CRLF kept', () => {
  const t = fixture(); const d = new ConfigDoc(t); assert.equal(apply(d, ctxOf(d), { part: 'KXA00001', action: 'remove' }).status, 'applied');
  const out = d.render(); const back = new ConfigDoc(out);
  assert.ok(!back.has('parts', 'KXA00001') && back.has('inActiveParts', 'KXA00001')); assert.equal(back.keys('parts')[0], '1990218', 'integer-like key keeps its place');
  assert.equal(out.split('\r\n').length, out.split('\n').length, 'all line endings are still CRLF');
  assert.deepEqual(back.get('inActiveParts', 'KXA00001'), new ConfigDoc(t).get('parts', 'KXA00001'), 'the object moved unchanged');
});

test('remove keeps an existing inactive entry and does nothing for an unknown part', () => {
  const d = new ConfigDoc(fixture()); const ctx = ctxOf(d);
  assert.match(apply(d, ctx, { part: 'KXA00004', action: 'remove' }).detail, /inactive copy already existed/);
  const back = new ConfigDoc(d.render()); assert.equal(back.has('parts', 'KXA00004'), false); assert.equal(back.get('inActiveParts', 'KXA00004').price.Red, '99', 'not overwritten');
  assert.equal(apply(d, ctx, { part: 'NOPE', action: 'remove' }).status, 'not-in-config');
});

test('price: whole-number string for every colour, only those values change', () => {
  const t = fixture(); const d = new ConfigDoc(t); const ctx = ctxOf(d); assert.equal(roundPrice(25.5653202), '26');
  assert.equal(apply(d, ctx, { part: '1990218', action: 'price', price: { from: 36, to: 29 } }).status, 'applied');
  const out = d.render(); const a = t.split(EOL), b = out.split(EOL); assert.equal(a.length, b.length);
  const changed = a.map((l, i) => [l, b[i]]).filter(([x, y]) => x !== y); assert.equal(changed.length, 2); assert.ok(changed.every(([x, y]) => x.replace('"36"', '"29"') === y));
  assert.equal(apply(d, ctx, { part: 'COMBINED', action: 'price', price: { to: 2 } }).status, 'not-in-config');
});

test('add: built from master + the other parts (colours, order, 3D position, image, related lists)', () => {
  const d = new ConfigDoc(fixture()); const ctx = ctxOf(d);
  const r = apply(d, ctx, { part: 'KXA00300', action: 'add', master: master({ accConflicts: 'KXA00001\nKXA00002\nKXA00777', essentialToAdd: 'KXA00001', essentialToRemove: 'NA' }) }); assert.equal(r.status, 'applied');
  const p = d.get('parts', 'KXA00300');
  assert.deepEqual(Object.keys(p.price), ['Red', 'Blue'], 'colours come from colorWiseStandardPartsMapping'); assert.deepEqual(Object.values(p.price), ['26', '26']);
  assert.equal(p.order, 2, 'highest order in Comfort/Seats is 1, so 2'); assert.deepEqual(p.threeDPos, POS, 'copied from a same-type part');
  assert.equal(p.thumbnailImage, 'https://h/uk/Accessories/Common/KXA00300_400.png'); assert.equal(p.displayName, 'NEW GRIPS - BROWN'); assert.equal(p.modelPartId, 'KXA00300:ON');
  assert.deepEqual(p.collisionProduct, ['KXA00001', 'KXA00002-R', 'KXA00002-P'], 'a pair in the config expands to both variants; unknown KXA00777 is dropped');
  assert.deepEqual(p.productToAdd, [{ applicableForColors: ['ALL_COLORS'], item: 'KXA00001' }]); assert.deepEqual(p.productToRemove, p.productToAdd, 'mirrors productToAdd when the master lists nothing to remove');
  assert.deepEqual(Object.keys(p), [...Object.keys(p)].sort(), 'keys are alphabetical like the other parts');
  assert.ok(r.notes.some((n) => /KXA00777/.test(n)) && r.notes.some((n) => /reminder: check the price object/.test(n)));
  apply(d, ctx, { part: 'KXA00301', action: 'add', master: master({ subCategory: 'Luggage' }) });
  const q = d.get('parts', 'KXA00301'); assert.equal(q.subCategory, 'Panniers'); assert.equal(q.order, 1, 'first part of a new group'); assert.deepEqual(q.threeDPos, { pan1: 0, pan2: 0, xAng: 0, yAng: 0, zoom: 0 }, 'no similar part: zeros');
  assert.ok(new ConfigDoc(d.render()).has('parts', 'KXA00301'), 'patched text parses');
});

test('add: pairs get consecutive orders and RIDER/PILLION names; image notes; non-3D parts', () => {
  const d = new ConfigDoc(fixture()); const ctx = ctxOf(d);
  apply(d, ctx, { part: 'KXA00181', action: 'add', pair: true, image: { file: 'KXA00181.jpg' }, master: master({ retailName: 'DELUXE FOOTPEGS', subCategory: 'Footpegs' }) });
  const r = d.get('parts', 'KXA00181-R'), pp = d.get('parts', 'KXA00181-P'); assert.equal(r.productName, 'DELUXE FOOTPEGS RIDER'); assert.equal(pp.productName, 'DELUXE FOOTPEGS PILLION'); assert.equal(pp.order, r.order + 1);
  assert.equal(r.thumbnailImage, 'https://h/uk/Accessories/Common/KXA00181_400.png', 'a .jpg note still becomes the _400.png pattern');
  apply(d, ctx, { part: 'KXA00182', action: 'add', image: { file: '1990486_400.png' }, master: master({ nonThreeD: true }) });
  const n3 = d.get('parts', 'KXA00182'); assert.equal(n3.isNonThreeD, true); assert.equal(n3.modelPartId, ''); assert.equal(n3.tripperPartIdRemove, ''); assert.equal('threeDPos' in n3, false); assert.ok(n3.thumbnailImage.endsWith('/1990486_400.png'), 'a _400.png file name in the note is used as given');
  assert.equal(apply(d, ctx, { part: 'NOMASTER', action: 'add' }).status, 'cannot-apply');
});

test('add: a part in inActiveParts is restored and refreshed from the master (names, price, image, lists)', () => {
  const d = new ConfigDoc(fixture()); const ctx = ctxOf(d);
  const r = apply(d, ctx, { part: 'KXA00099', action: 'add', master: master({ subCategory: 'Mirrors', accConflicts: 'KXA00001', essentialToAdd: 'NA' }) });
  assert.equal(r.status, 'applied'); assert.match(r.detail, /restored from inActiveParts/);
  const p = d.get('parts', 'KXA00099'); assert.equal(p.productName, 'NEW GRIPS'); assert.deepEqual(Object.values(p.price), ['26', '26']); assert.equal(p.thumbnailImage, 'https://h/uk/Accessories/Common/KXA00099_400.png');
  assert.deepEqual(p.collisionProduct, ['KXA00001']); assert.equal('productToAdd' in p, false, 'master lists none, so it is removed'); assert.deepEqual(p.threeDPos, POS, 'kept from the inactive copy');
  assert.ok(r.notes.some((n) => /productName: .* -> /.test(n))); assert.ok(d.has('inActiveParts', 'KXA00099'), 'the inactive entry is kept');
});

test('rename and image update existing parts in place', () => {
  const t = fixture(); const d = new ConfigDoc(t); const ctx = ctxOf(d);
  assert.equal(apply(d, ctx, { part: 'KXA00001', action: 'rename', master: master() }).status, 'applied');
  assert.equal(apply(d, ctx, { part: 'KXA00005', action: 'rename', master: master() }).status, 'applied', 'a part without displayName gets one');
  assert.equal(apply(d, ctx, { part: 'KXA00001', action: 'image', image: { file: '1990486_400.png' } }).status, 'applied');
  const out = d.render(); const back = new ConfigDoc(out);
  assert.equal(back.get('parts', 'KXA00001').productName, 'NEW GRIPS'); assert.equal(back.get('parts', 'KXA00001').displayName, 'NEW GRIPS - BROWN'); assert.ok(back.get('parts', 'KXA00001').thumbnailImage.endsWith('/1990486_400.png'));
  assert.equal(back.get('parts', 'KXA00005').displayName, 'NEW GRIPS - BROWN'); assert.deepEqual(back.keys('parts'), new ConfigDoc(t).keys('parts'), 'positions unchanged');
  const changed = t.split(EOL).filter((l) => !out.split(EOL).includes(l)).filter((l) => /productName|displayName|thumbnailImage/.test(l)); assert.ok(changed.length >= 3, 'only name/image lines were touched in KXA00001');
  assert.equal(apply(d, ctx, { part: 'NOPE', action: 'rename', master: master() }).status, 'not-in-config');
});

test('skip and ask are not applied; check reports the state for every action', () => {
  const d = new ConfigDoc(fixture()); const ctx = ctxOf(d);
  assert.equal(applyChange(d, { part: 'KXA00001', action: 'remove', decision: 'skip', why: 'because' }, ctx).status, 'skipped'); assert.equal(applyChange(d, { part: 'KXA00001', action: 'remove', decision: 'ask' }, ctx).status, 'unresolved');
  const chk = (ch) => checkChange(d, { decision: 'apply', ...ch }, ctx);
  assert.equal(chk({ part: 'KXA00001', action: 'remove' }).state, 'todo'); assert.equal(chk({ part: 'NOPE', action: 'remove' }).state, 'n/a'); assert.equal(chk({ part: '1990218', action: 'price', price: { to: 36 } }).state, 'ok');
  assert.equal(chk({ part: 'ZZZ', action: 'add' }).state, 'todo'); assert.equal(chk({ part: 'KXA00001', action: 'rename', master: master() }).state, 'todo'); assert.equal(chk({ part: 'KXA00001', action: 'image', image: { file: 'KXA00001_400.png' } }).state, 'ok');
  apply(d, ctx, { part: 'KXA00001', action: 'remove' }); assert.equal(chk({ part: 'KXA00001', action: 'remove' }).state, 'ok');
});

test('reminder lists parts whose price object lacks a standard colour', () => {
  const d = new ConfigDoc(build({ A: part('A', { price: { Red: '1' } }), B: part('B') }, {})); const rem = priceVariantReminders(d, makeContext(d));
  assert.deepEqual(rem, [['A', ['Blue']]]);
});
