import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ConfigDoc } from '../lib/doc.mjs';
import { applyChange, checkChange, makeContext, roundPrice } from '../lib/changes.mjs';
import { stringifyAt } from '../lib/ordered-json.mjs';

const EOL = '\r\n'; const at = (v) => stringifyAt(v, { base: '        ', step: '  ', eol: EOL });
const part = (pn, over = {}) => ({ category: 'Comfort', collisionProduct: [''], displayName: `D ${pn}`, gmapartnumber: pn, isHelperProduct: '', isHidden: '', modelPartId: `${pn}:ON`, order: 1,
  price: { Red: '36', Blue: '36' }, productId: pn, productName: `N ${pn}`, subCategory: 'Seats', thumbnailImage: `https://h/Acc/J1B/${pn}.png`, tripperPartIdRemove: `${pn}:OFF`, ...over });
// integer-like keys + CRLF + odd indentation, like the real files
const build = (parts, inactive) => ` {${EOL}        "categoryOrder": ${at(['Comfort.Seats', 'Comfort.Panniers'])},${EOL}        "inActiveParts": ${at(inactive)},${EOL}        "parts": ${at(parts)}${EOL}      }`;
const fixture = () => build({ 1990218: part('1990218'), P1: part('P1'), 'P2-R': part('P2-R'), 'P2-P': part('P2-P') }, { OLD: part('OLD'), P2: part('P2') });
const master = (over = {}) => ({ retailName: 'NEW GRIPS', displayName: 'NEW GRIPS - BROWN', category: 'Comfort', subCategory: 'Luggage', price: 25.565, essentialToAdd: 'NA', essentialToRemove: 'NA', accConflicts: 'KXA00002\nKXA00003', nonThreeD: false, ...over });

test('an untouched render is byte-identical (CRLF, odd indentation, integer-like keys)', () => { const t = fixture(); assert.equal(new ConfigDoc(t).render(), t); });

test('remove moves the part; every other line stays byte-identical', () => {
  const t = fixture(); const d = new ConfigDoc(t); const ctx = makeContext(d);
  const r = applyChange(d, { part: 'P1', action: 'remove', decision: 'apply' }, ctx); assert.equal(r.status, 'applied');
  const out = d.render(); const back = new ConfigDoc(out);
  assert.ok(!back.has('parts', 'P1') && back.has('inActiveParts', 'P1'));
  assert.deepEqual(back.keys('parts'), ['1990218', 'P2-R', 'P2-P'], 'integer-like key keeps its place');
  assert.equal(out.includes('\n') && out.split('\r\n').length, out.split('\n').length, 'all line endings are still CRLF');
  const lost = new Set(t.split(EOL).filter((l) => !out.split(EOL).includes(l)));
  assert.ok([...lost].every((l) => /P1|alwaysAdd|[A-Za-z]/.test(l)), 'only lines of the moved part disappeared from their old place');
  assert.deepEqual(back.get('inActiveParts', 'P1'), new ConfigDoc(t).get('parts', 'P1'), 'the object moved unchanged');
});

test('remove keeps an existing inactive entry and does nothing for an unknown part', () => {
  const d = new ConfigDoc(build({ P3: part('P3', { price: { Red: '1' } }), P4: part('P4') }, { P3: part('P3', { price: { Red: '99' } }) })); const ctx = makeContext(d);   // P3 is in BOTH objects, like KXA00001 in the real file
  assert.match(applyChange(d, { part: 'P3', action: 'remove', decision: 'apply' }, ctx).detail, /inactive copy already existed/);
  const back = new ConfigDoc(d.render());
  assert.equal(back.has('parts', 'P3'), false); assert.equal(back.get('inActiveParts', 'P3').price.Red, '99', 'the existing inactive entry was NOT overwritten');
  assert.equal(applyChange(d, { part: 'NOPE', action: 'remove', decision: 'apply' }, ctx).status, 'not-in-config');
});

test('price sets every colour to a whole-number string and only touches those values', () => {
  const t = fixture(); const d = new ConfigDoc(t); const ctx = makeContext(d);
  assert.equal(roundPrice(25.5653202), '26');
  assert.equal(applyChange(d, { part: '1990218', action: 'price', price: { from: 36, to: 29 }, decision: 'apply' }, ctx).status, 'applied');
  const out = d.render(); const a = t.split(EOL), b = out.split(EOL); assert.equal(a.length, b.length);
  const changed = a.map((l, i) => [l, b[i]]).filter(([x, y]) => x !== y); assert.equal(changed.length, 2, 'two colour values');
  assert.ok(changed.every(([x, y]) => x.replace('"36"', '"29"') === y));
  assert.equal(applyChange(d, { part: 'COMBINED', action: 'price', price: { from: 1, to: 2 }, decision: 'apply' }, ctx).status, 'not-in-config');
});

test('add builds a part from the master; pair, non-3D and restore-from-inactive follow the rules', () => {
  const d = new ConfigDoc(fixture()); const ctx = makeContext(d, { subCategoryMap: { Luggage: 'Panniers' } });
  const a = applyChange(d, { part: 'KXA00189', action: 'add', master: master(), decision: 'apply' }, ctx); assert.equal(a.status, 'applied');
  const p = d.get('parts', 'KXA00189');
  assert.equal(p.modelPartId, 'KXA00189:ON'); assert.equal(p.tripperPartIdRemove, 'KXA00189:OFF'); assert.equal(p.subCategory, 'Panniers'); assert.deepEqual(p.collisionProduct, ['KXA00002', 'KXA00003']);
  assert.deepEqual(Object.values(p.price), ['26', '26']); assert.equal(p.thumbnailImage, 'https://h/Acc/J1B/KXA00189.png');
  assert.ok(a.notes.some((n) => /threeDPos/.test(n)) && a.notes.some((n) => /order .* proposed/.test(n)));
  applyChange(d, { part: 'KXA00181', action: 'add', pair: true, master: master({ retailName: 'DELUXE FOOTPEGS' }), decision: 'apply' }, ctx);
  assert.equal(d.get('parts', 'KXA00181-R').productName, 'DELUXE FOOTPEGS RIDER'); assert.equal(d.get('parts', 'KXA00181-P').productName, 'DELUXE FOOTPEGS PILLION');
  applyChange(d, { part: 'KXA00121', action: 'add', master: master({ nonThreeD: true }), decision: 'apply' }, ctx);
  const n3 = d.get('parts', 'KXA00121'); assert.equal(n3.isNonThreeD, true); assert.equal(n3.modelPartId, ''); assert.equal(n3.tripperPartIdRemove, '');
  assert.match(applyChange(d, { part: 'OLD', action: 'add', master: master(), decision: 'apply' }, ctx).detail, /restored from inActiveParts/);
  assert.equal(applyChange(d, { part: 'NOMASTER', action: 'add', decision: 'apply' }, ctx).status, 'cannot-apply');
  const back = new ConfigDoc(d.render()); assert.ok(back.has('parts', 'KXA00189') && back.has('parts', 'KXA00181-R'), 'the patched text parses and contains the new parts');
});

test('skip and ask decisions are not applied; check reports the state', () => {
  const d = new ConfigDoc(fixture()); const ctx = makeContext(d);
  assert.equal(applyChange(d, { part: 'P1', action: 'remove', decision: 'skip', why: 'because' }, ctx).status, 'skipped');
  assert.equal(applyChange(d, { part: 'P1', action: 'remove', decision: 'ask' }, ctx).status, 'unresolved');
  assert.equal(d.has('parts', 'P1'), true);
  assert.equal(checkChange(d, { part: 'P1', action: 'remove', decision: 'apply' }).state, 'todo');
  assert.equal(checkChange(d, { part: 'NOPE', action: 'remove', decision: 'apply' }).state, 'n/a');
  assert.equal(checkChange(d, { part: '1990218', action: 'price', price: { to: 36 }, decision: 'apply' }).state, 'ok');
  assert.equal(checkChange(d, { part: 'ZZZ', action: 'add', decision: 'apply' }).state, 'todo');
  applyChange(d, { part: 'P1', action: 'remove', decision: 'apply' }, ctx);
  assert.equal(checkChange(d, { part: 'P1', action: 'remove', decision: 'apply' }).state, 'ok');
});
