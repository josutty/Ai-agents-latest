import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import XLSX from 'xlsx';

const root = join(dirname(fileURLToPath(import.meta.url)), '..'); const dir = mkdtempSync(join(tmpdir(), 'audit-'));
const sheet = (rows, formulas = {}) => { const ws = XLSX.utils.aoa_to_sheet(rows); for (const [addr, c] of Object.entries(formulas)) ws[addr] = c; return ws; };
test('the Excel reader keeps cached formula results (0 and blank) and classifies every row', () => {
  const audit = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(audit, sheet([['T1', 'BIKE'], ['PART NUMBER', 'NAME', 'GB', 'CFG', 'NOTES', 'RECHECK', 'UK'],
    ['P1', 'ONE', 10, 'REMOVE'], ['P2', 'TWO', 29, 'MISSING', null, null, 'Not UK'], ['P3', 'THREE', 29, 36], ['P4', 'FOUR', 69, null, 'Rider and Pillion shown as set'],
    ['P5', 'FIVE', 19, null, 'NOT for UK Market'], ['P6', 'SIX', 5, 'MISSING'], ['P7', 'SEVEN', 10, 10], ['P8', 'DELUXE FOOTPEGS', 89, 'MISSING']],
    { D6: { t: 'n', v: 0, f: 'IFERROR(1/0,0)' }, D7: { t: 's', v: '', f: '""' } }), 'T1-AUDIT');
  const mas = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(mas, sheet([['T1'], ['PART', 'RETAIL', 'DISPLAY', 'CAT', 'SUB', 'THUMB', 'PRICE', 'DESC', '', 'AVAIL', 'NOTES', 'ADD', 'REMOVE', 'OE', 'CONFLICTS'],
    ['P2', 'TWO', 'TWO D', 'Comfort', 'Seats', 'u', '29', '', null, 'AVAILABLE', 'Not shown in 3D on configurator', 'NA', 'NA', 'NA', 'NA'],
    ['P8', 'DELUXE FOOTPEGS', 'DF', 'Comfort', 'Footpegs', 'u', '89', '', null, 'AVAILABLE', null, 'NA', 'NA', 'NA', 'NA']]), 'T1-MASTER');
  XLSX.writeFile(audit, join(dir, 'audit.xlsx')); XLSX.writeFile(mas, join(dir, 'master.xlsx'));
  const real = JSON.parse(readFileSync(join(root, 'mapping.nec-uk.json'), 'utf8'));
  writeFileSync(join(dir, 'mapping.json'), JSON.stringify({ ...real, bikes: [{ code: 'T1', auditSheet: 'T1-AUDIT', masterSheet: 'T1-MASTER' }] }));
  const r = spawnSync('node', [join(root, 'read-audit.mjs'), '--audit', join(dir, 'audit.xlsx'), '--master', join(dir, 'master.xlsx'), '--mapping', join(dir, 'mapping.json'), '--decisions', join(root, 'decisions.json'), '--out', join(dir, 'cl.json'), '--questions', join(dir, 'q.md')], { encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
  const ch = Object.fromEntries(JSON.parse(readFileSync(join(dir, 'cl.json'), 'utf8')).bikes[0].changes.map((c) => [c.part, c]));
  assert.equal(ch.P1.action, 'remove'); assert.equal(ch.P1.decision, 'apply');
  assert.equal(ch.P2.action, 'add'); assert.equal(ch.P2.decision, 'apply', 'precedent: add even when notes say Not UK'); assert.equal(ch.P2.master.nonThreeD, true);
  assert.equal(ch.P3.action, 'price'); assert.deepEqual(ch.P3.price, { from: 36, to: 29 });
  assert.equal(ch.P4.action, 'price', 'cached 0 must survive'); assert.deepEqual(ch.P4.flags.sort(), ['setPricing', 'zeroConfig']); assert.equal(ch.P4.decision, 'skip');
  assert.equal(ch.P5.action, 'review', 'cached blank must survive'); assert.equal(ch.P5.decision, 'skip');
  assert.equal(ch.P6.action, 'add'); assert.equal(ch.P6.decision, 'ask', 'not in the master');
  assert.equal(ch.P7, undefined, 'same price = no change');
  assert.equal(ch.P8.pair, true, 'footpegs are written as a rider/pillion pair');
  assert.match(readFileSync(join(dir, 'q.md'), 'utf8'), /Needs your answer \(1\)/);
});
