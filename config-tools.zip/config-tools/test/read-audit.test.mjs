import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import XLSX from 'xlsx';

const root = join(dirname(fileURLToPath(import.meta.url)), '..'); const dir = mkdtempSync(join(tmpdir(), 'audit-'));
const sheet = (rows, formulas = {}) => { const ws = XLSX.utils.aoa_to_sheet(rows); for (const [addr, c] of Object.entries(formulas)) ws[addr] = c; return ws; };
test('the Excel reader keeps cached formula results and applies the owner\'s rules to every row', () => {
  const audit = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(audit, sheet([['T1', 'BIKE'], ['PART NUMBER', 'NAME', 'GB', 'CFG', 'NOTES', 'RECHECK', 'UK'],
    ['P1', 'ONE', 10, 'REMOVE'], ['P2', 'TWO', 29, 'MISSING', null, null, 'Not UK'], ['P3', 'THREE', 29, 36], ['P4', 'FOUR', 69, null, 'Rider and Pillion shown as set'],
    ['P5', 'FIVE', 19, null, 'NOT for UK Market'], ['P6', 'SIX', 5, 'MISSING'], ['P7', 'SEVEN', 10, 10], ['P8', 'DELUXE FOOTPEGS', 89, 'MISSING'],
    ['P9', 'NINE', 19, 20], ['P10', 'TEN', 50, 55, 'Update name'], ['P11', 'ELEVEN', 60, 66, 'Update image P11_400.png'], ['P12', 'TWELVE', 70, 'MISSING', 'Please update image to P12.jpg']],
    { D6: { t: 'n', v: 0, f: 'IFERROR(1/0,0)' }, D7: { t: 's', v: '', f: '""' } }), 'T1-AUDIT');
  const mrow = (pn, price, extra = {}) => [pn, `R ${pn}`, `D ${pn}`, 'Comfort', 'Seats', 'u', price, '', null, 'AVAILABLE', extra.notes ?? null, 'NA', 'NA', 'NA', 'NA'];
  const mas = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(mas, sheet([['T1'], ['PART', 'RETAIL', 'DISPLAY', 'CAT', 'SUB', 'THUMB', 'PRICE', 'DESC', '', 'AVAIL', 'NOTES', 'ADD', 'REMOVE', 'OE', 'CONFLICTS'],
    mrow('P2', '29', { notes: 'Not shown in 3D on configurator' }), mrow('P3', '31'), mrow('P8', '89'), mrow('P10', '55'), mrow('P12', '70')]), 'T1-MASTER');
  XLSX.writeFile(audit, join(dir, 'audit.xlsx')); XLSX.writeFile(mas, join(dir, 'master.xlsx'));
  const real = JSON.parse(readFileSync(join(root, 'mapping.nec-uk.json'), 'utf8'));
  writeFileSync(join(dir, 'mapping.json'), JSON.stringify({ ...real, bikes: [{ code: 'T1', auditSheet: 'T1-AUDIT', masterSheet: 'T1-MASTER' }] }));
  const r = spawnSync('node', [join(root, 'read-audit.mjs'), '--audit', join(dir, 'audit.xlsx'), '--master', join(dir, 'master.xlsx'), '--mapping', join(dir, 'mapping.json'), '--decisions', join(root, 'decisions.json'), '--out', join(dir, 'cl.json'), '--questions', join(dir, 'q.md')], { encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
  const bike = JSON.parse(readFileSync(join(dir, 'cl.json'), 'utf8')).bikes[0]; const ch = Object.fromEntries(bike.changes.map((c) => [`${c.part}|${c.action}`, c]));
  assert.equal(ch['P1|remove'].decision, 'apply');
  assert.equal(ch['P2|remove'].decision, 'apply', 'MISSING but not UK -> remove, never add'); assert.ok(ch['P2|remove'].flags.includes('notUkMissing')); assert.equal(ch['P2|add'], undefined);
  assert.equal(ch['P3|price'].price.to, 31, 'the MASTER price wins over the audit price'); assert.equal(ch['P3|price'].price.source, 'master');
  assert.equal(ch['P4|price'].decision, 'skip', 'cached 0 survives: set-priced rows stay unchanged'); assert.ok(ch['P4|price'].flags.includes('setPricing') && ch['P4|price'].flags.includes('zeroConfig'));
  assert.equal(ch['P5|remove'].decision, 'apply', 'cached blank + not UK -> remove'); assert.ok(ch['P5|remove'].flags.includes('notUkNoAction'));
  assert.equal(ch['P6|add'].decision, 'ask'); assert.equal(ch['P7|price'], undefined); assert.equal(ch['P8|add'].pair, true);
  assert.equal(ch['P9|price'].price.source, 'audit', 'no master price: the audit price is used'); assert.ok(ch['P9|price'].flags.includes('auditPrice'));
  assert.ok(ch['P10|price'] && ch['P10|rename'].master.retailName === 'R P10', 'a name note adds a rename taken from the master');
  assert.ok(ch['P11|price'] && ch['P11|image'].image.file === 'P11_400.png', 'an image note on an existing part adds an image change');
  assert.equal(ch['P12|add'].image.file, 'P12.jpg', 'an image note on an add travels with it'); assert.equal(ch['P12|image'], undefined);
  assert.ok(bike.masterParts.includes('P2') && bike.masterParts.includes('P12'), 'the bike\'s master part numbers are recorded');
  assert.match(readFileSync(join(dir, 'q.md'), 'utf8'), /Needs your answer \(1\)/);
});
