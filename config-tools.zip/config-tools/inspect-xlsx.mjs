#!/usr/bin/env node
// Look at a workbook's layout WITHOUT reading it all: sheet names, size, and the first rows (cached values; formulas show their result).
//   node inspect-xlsx.mjs <file.xlsx> [--sheet "name"] [--rows 6] [--cols 10]
import XLSX from 'xlsx';
import { parseArgs, cut } from './lib/cli.mjs';
const a = parseArgs(process.argv.slice(2)); const file = a._[0]; if (!file) { console.error('usage: node inspect-xlsx.mjs <file.xlsx> [--sheet name] [--rows 6] [--cols 10]'); process.exit(2); }
const wb = XLSX.readFile(file, { cellFormula: false, cellStyles: false, cellHTML: false, sheets: typeof a.sheet === 'string' ? [a.sheet] : undefined, bookSheets: !a.sheet });
if (!a.sheet) { console.log(`${wb.SheetNames.length} sheets in ${file}:`); wb.SheetNames.forEach((n, i) => console.log(`  ${String(i + 1).padStart(2)}. ${n}`)); console.log('\nAdd --sheet "<name>" to see its first rows.'); process.exit(0); }
const ws = wb.Sheets[a.sheet]; if (!ws) { console.error(`✘ no sheet named "${a.sheet}"`); process.exit(1); }
const range = XLSX.utils.decode_range(ws['!ref']); range.s.r = 0; range.s.c = 0; const rows = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null, blankrows: true, range });
const nRows = Number(a.rows ?? 6); const nCols = Number(a.cols ?? 10); const L = (i) => XLSX.utils.encode_col(i);
console.log(`"${a.sheet}": ${rows.length} rows x ${range.e.c + 1} columns. First ${nRows} rows, columns A-${L(nCols - 1)}:`);
rows.slice(0, nRows).forEach((r, i) => console.log(`  row ${i + 1}: ${r.slice(0, nCols).map((c, j) => `${L(j)}=${c === null ? '·' : JSON.stringify(cut(c, 24))}`).join('  ')}`));
