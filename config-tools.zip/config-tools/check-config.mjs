#!/usr/bin/env node
// Check a config JSON against the change list: is each audit correction already reflected? Exit code 1 if something is still to do.
//   node check-config.mjs --config classic-350.json --changes change-list.json --bike J1A [--verbose]
import { readFileSync } from 'node:fs';
import { ConfigDoc } from './lib/doc.mjs';
import { checkChange, contextFor, priceVariantReminders } from './lib/changes.mjs';
import { parseArgs, need, cut, mdRow } from './lib/cli.mjs';

const a = parseArgs(process.argv.slice(2));
const list = JSON.parse(readFileSync(need(a, 'changes'), 'utf8')); const bike = list.bikes.find((b) => b.code === need(a, 'bike', '(e.g. J1A)'));
if (!bike) { console.error(`✘ bike ${a.bike} is not in the change list`); process.exit(2); }
const mapping = a.mapping ? JSON.parse(readFileSync(a.mapping, 'utf8')) : {}; const doc = new ConfigDoc(readFileSync(need(a, 'config'), 'utf8')); const ctx = contextFor(doc, bike, mapping);
const res = bike.changes.map((ch) => ({ ch, r: checkChange(doc, ch, ctx) })); const n = (s) => res.filter((x) => x.r.state === s).length;
console.log(`${bike.code} vs ${a.config}:  ✔ done ${n('ok')} · ✘ still to do ${n('todo')} · n/a (not in config) ${n('n/a')} · skipped ${n('skipped')} · unresolved ${n('unresolved')}`);
for (const { ch, r } of res) if (r.state === 'todo' || (a.verbose && r.state !== 'ok')) console.log(`  ${r.state === 'todo' ? '✘' : '·'} ${ch.part.padEnd(11)} ${ch.action.padEnd(6)} ${r.state.padEnd(10)} ${cut(r.detail, 90)}`);
const rem = priceVariantReminders(doc, ctx); if (rem.length) console.log(`  reminder: ${rem.length} part(s) have a price object missing a standard colour (e.g. ${rem.slice(0, 3).map(([k, m]) => `${k}: ${m.length} missing`).join('; ')}) — please check`);
process.exit(n('todo') ? 1 : 0);
