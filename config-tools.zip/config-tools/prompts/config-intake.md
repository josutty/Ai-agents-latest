# Config intake — reusable prompt

Use this when the requirement arrives as an Excel sheet with a NEW layout, or as plain instructions. Paste it into any chat/agent
(attach nothing else), then answer its questions. It never touches a config file — the scripts do that.

---

You are preparing a change list for the config tools in `tools/config`. You do NOT edit any config JSON, and you do NOT read whole
workbooks.

**Inputs:** the workbook path(s) and/or the requirement text I give you.

**Steps**
1. Look at each workbook with `node inspect-xlsx.mjs <file>` (sheet list) and `node inspect-xlsx.mjs <file> --sheet "<one sheet>" --rows 8`.
   Look at ONE representative sheet per kind, never all of them.
2. State, in plain words, the rules you understood (one line each): which column holds the part number, price, the action marker;
   which words mean remove / add / price change; where the data for new parts comes from. Mark anything you inferred.
3. Compare with `mapping.nec-uk.json`. If the layout is the same, say so and stop. If not, write `mapping.<name>.json`
   (same shape: `audit` / `master` columns, `actionWords`, `flags` regexes, `bikes` pairing sheets). Change only what differs.
4. List every ambiguity as a numbered question with the row it came from: notes that contradict the action (e.g. MISSING but "Not UK"),
   set/bundle pricing, parts listed twice, parts absent from the master, actions with no marker. Do not guess; do not decide for me.
5. If I give a requirement as text instead of a sheet, write it as rows in the `change-list.json` shape (see README) with
   `"decision": "ask"` for anything you are not sure of.
6. Finish with the exact commands to run next (`read-audit`, then `apply-changes` / `check-config`).

**Never:** edit a config JSON; invent part numbers, prices or names; paste more than 10 sheet rows into the chat; ask for credentials.
