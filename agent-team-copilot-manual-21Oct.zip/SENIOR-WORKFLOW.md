# Senior-developer workflow — you drive, scripts do the bookkeeping (GitHub Copilot)

You skip the orchestrator. Agents are used only for thinking work (planning, writing code, writing tests); everything
mechanical — progress tracking, start/finish records, checks, scope, library and design verification, commits — is done by
`tools/task.mjs` and costs **zero tokens**. A builder session reads one **context pack** (the task + only the excerpts it
needs) instead of searching the plan.

## Attach syntax in GitHub Copilot
| You want to attach | Write |
|---|---|
| a file | `#file:plan/packs/TASK-005.builder.md` |
| plain session (no orchestrator) | pick the built-in **Agent** mode in the chat dropdown (not the orchestrator) |
| the pack isn't in the picker | say it in words: `Read the file plan/packs/TASK-005.builder.md and implement TASK-005 exactly as it says.` |

## Setup once
1. `git config core.hooksPath .githooks` · `node tools/check-install.mjs` (fix every ❌) · set `models.json` → `node tools/set-models.mjs`
2. Work on a branch: `git checkout -b feat/<name>` (the tool refuses `main`, `master`, `develop`). **No git on this laptop?** See "Working without git" below — everything still works.
3. Models: **strong** (Opus-class) for the planning chain below; **Sonnet-class** for packs; cheaper only for trivial tasks.

## A. Planning chain (Phases 0–2) — one agent per NEW session, in this order
Prompt shape (same every time):
```
Follow #file:.github/agents/<agent>.agent.md and #file:AGENTS.md. You are ONLY this agent — do not start the next agent's work.
<step line from the table>  Finish with the HANDOFF line.
```
| # | Agent | Step line |
|---|---|---|
| 1 | app-bootstrap | `Mode: new-project. Run 1 (Phase 0). Branch name: feat/<name>.` |
| 2 | wireframe-analyzer | `Mode: new-project. UX HTML: inputs/ux/**/*.html (a screen inside a combined file is file.html#screen-id). Client FSD doc: inputs/fsd-spec.md.` |
| 3 | hybrid-api-config | `Mode: new-project. Backend spec: inputs/api/backend-api.yaml (partial).` |
| 4 | schema-parser | `Mode: new-project. Spec: plan/generated/api-spec.yaml.` |
| 5 | mock-data-generator | `Mode: new-project.` |
| 6 | fsd-planner | `Mode: new-project. Client FSD doc: inputs/fsd-spec.md.` |
| 7 | coverage-checker | `Mode: new-project. stage=plan.` |
| — | **Gate 1 (you)** | read `plan/coverage-matrix.md` (gaps first), `analysis/capabilities.md`, `plan/library-decisions.md` (approve), `analysis/display-rules.md` (answer open questions), `plan/generated/backend-gaps.md` |
| 8 | app-bootstrap | `Mode: new-project. Run L (install only the approved rows of plan/library-decisions.md).` |
| 9 | architect | `Mode: new-project. Phase 2.` |
| 10 | coverage-checker | `Mode: new-project. stage=tasks.` |
| — | **Gate 2 (you)** | `plan/PROGRESS.md` + 2–3 task files: small? Design section has Source, Spec and **Route** (page tasks)? |
| 11 | store-architect | `Mode: new-project. Phase 3a.` |
| 12 | styling-engineer | `Mode: new-project. Phase 3a.` |
| 13 | app-bootstrap | `Mode: new-project. Run 2 (app shell).` |

Read each agent's last line (HANDOFF). DONE/READY → next. Anything else → fix what it names and re-run that agent.

## B. The task loop (this is where you save the tokens)
```
node tools/task.mjs status                      # what's done, what's ready
node tools/task.mjs start TASK-005              # branch/clean-tree guard, start-sha, status in-progress
```
**`tests: first` tasks** (data, logic, forms, interactive widgets, display rules, pages, bugs):
```
node tools/task.mjs pack TASK-005 --role tests
   NEW session, plain agent, attach plan/packs/TASK-005.tests.md:   "Write the tests for TASK-005 exactly as this pack says."
node tools/task.mjs red TASK-005                # proves the tests fail for a VALID reason (TDD), records it
node tools/task.mjs pack TASK-005
   NEW session, plain agent, attach plan/packs/TASK-005.builder.md: "Implement TASK-005 exactly as this pack says."
```
**`tests: after` tasks** (purely visual): build first, then tests.
```
node tools/task.mjs pack TASK-005
   NEW session: attach plan/packs/TASK-005.builder.md:  "Implement TASK-005 exactly as this pack says."
node tools/task.mjs pack TASK-005 --role tests          # now it includes the code that exists
   NEW session: attach plan/packs/TASK-005.tests.md:    "Write the tests for TASK-005 exactly as this pack says."
```
**Then, for every task:**
```
node tools/task.mjs check TASK-005 [--design]   # typecheck · eslint (task files) · steiger · related tests · design (--design, page tasks)
   ✘ → attach plan/packs/TASK-005.failures.md to the same session: "Fix these failures. Touch only the task's files."
node tools/task.mjs done TASK-005               # check + scope + libraries (+ design for pages) → status done → commit by path
```
`done` replaces the per-task reviewer: it refuses if a file outside the task's Files table changed, if a library that isn't
approved in `plan/library-decisions.md` was added, if any check fails, or (page tasks) if the design check has blocking differences.
It commits only the task's files plus `plan/PROGRESS.md`, the task file, its history and the design report.

## C. What to run yourself (zero tokens) and what to use agents for
| Job | Use |
|---|---|
| Typecheck, lint, FSD rules, related tests, design compare, scope, libraries, progress, commits | `tools/task.mjs` (above) |
| Review | you read the `done` result; optionally run the **reviewer** agent once per 4–5 tasks, on a different model family, for a second opinion |
| Planning chain (section A), foundation | agents (strong models) |
| Writing code and tests | plain session + pack (Sonnet-class) |
| A bug you can't find, a coder stuck | **debugger** agent: attach `plan/packs/<TASK>.failures.md` |
| Coverage tracing | **coverage-checker** at Gates 1, 2 and release |
| Boilerplate (types, mocks) | already generated by schema-parser / mock-data-generator |

## D. Release (Phase 4) — once, not per task
```
npm run typecheck && npm run lint && npm test && npm run build
npm run build-storybook && npm run coverage && npm run e2e
node tools/design-spec.mjs compare inputs/ux/<file>.html#<screen> /<route> --start      # every screen
```
Then the **coverage-checker** (`stage=release`) and **Gate 3**: open each `plan/design-diff/<screen>/` (design.png next to build.png).

## Token habits
- **One session per pack.** Attach only the pack (and later only `failures.md`) — never paste logs or let the agent search the plan.
- **Never let an agent run the whole suite or build Storybook** — the pack says so, `check` does it cheaply.
- `pack` prints what each section costs; a thin task file gives a thin pack — fix the task, not the prompt.
- Routine tasks: Sonnet-class or cheaper. Spend Opus-class on planning and debugging.

## Limits (read once)
- Tested here: Node 22, Linux, a two-task sample project (pack, red, check, design check, scope, library check, done/commit, re-run after a failed commit) in git mode, plus the whole flow with no `.git` folder and with a broken `git` command (snapshot, scope, library check, undo, done). **Not tested on Windows** — it uses `git` and `npx` from your PATH; tell me if anything misbehaves.
- The pack picks excerpts by matching component names and slice paths from the task file. A task file that doesn't name its components gets a thinner pack.
- `red` is a pattern check (assertion or missing-import failure = valid; syntax/reference/setup errors = suspect), not a proof.
- Scope and library checks are only as good as the task's Files table — check it at Gate 2.
- The design check measures what `design-spec` measures (labels, columns, page background, card, text placement, fonts, colors, controls); spacing between blocks, icons and hover states are still yours at Gate 3.
- One task in progress at a time; `start` refuses a dirty tree on purpose.

## Working without git
Git missing, "not recognized", or the folder isn't a repository? You are **not blocked**. Two ways:
1. **Easiest:** create the file `plan/run-options.md` with one line: `git: off` (or just run any `node tools/task.mjs start …` — it writes the line itself when it can't find git).
2. **Or fix git:** install Git for Windows, reopen VS Code, then `git init` → `git add -A` → `git commit -m initial` and delete the `git: off` line.

With `git: off`:
| Normally (git) | Now |
|---|---|
| work branch | none — you work in your folder |
| start-sha | `start` saves a **snapshot** of every file hash and a **backup** of the task's files (`plan/history/<id>.snapshot.json`, `<id>.backup/`) |
| scope check (`git diff`) | compares against the snapshot — still catches edited, new and deleted files outside the task |
| commit by path | skipped — `done` marks the task done and says "nothing committed" |
| undo (`git restore`) | `node tools/task.mjs undo TASK-005` (preview), then `--yes`: restores the task's edited files, deletes the files it created |
Agents follow the same rule (AGENTS.md §7): app-bootstrap and the orchestrator skip branches and commits and keep going.
Limits: undo only covers the files in the task's Files table; there is no history, no diff viewer and no `git push` — copy or zip the folder yourself as a backup now and then.

## Troubleshooting
| You see | Do |
|---|---|
| `start`: "working tree not clean" | commit or stash your changes, or `--force` |
| `start`: "you are on main" | `git checkout -b feat/<name>` |
| "git unavailable" / "cannot create branch" | create `plan/run-options.md` with `git: off` (see "Working without git") |
| "no design check: … no Source/Route" | add `Route: /path` (and `Source:`) to the task's Design section — the architect now writes it; older tasks need the line by hand |
| `done`: "OUTSIDE the Files table" | revert those edits, or add the file to the task's Files table if it is truly part of the task |
| `done`: "library NOT approved" | approve the row in `plan/library-decisions.md` (Gate 1 decision) or remove the dependency |
| `done`: "commit failed" | set `git config user.name/user.email`; fix the pre-commit message; run `done` again (safe to repeat) |
| `red`: "tests already PASS" | the test doesn't test the missing behaviour — rewrite it |
| `npm` / `npx` fail with "running scripts is disabled on this system" (PowerShell) | put `node tools/run.mjs` in front: `node tools/run.mjs npm run typecheck`, `node tools/run.mjs npx vitest …`, `node tools/run.mjs openapi-typescript <spec> -o <out>`. Or use `npm.cmd` / `npx.cmd`, or switch the VS Code terminal profile to Command Prompt. (`node tools/task.mjs …` already runs its checks through cmd.exe, so it is not affected.) Don't override a policy your IT set. |
| the pack is **not listed** when you type `@` (the other plan files are) | the editor's `@` picker skips git-ignored files, and older versions of the tool ignored `plan/packs/`. Run any `node tools/task.mjs …` command once with the new tool (it removes that ignore line), or delete the line `plan/packs/` from `.git/info/exclude`. Meanwhile attach by words — always works: `Read the file plan/packs/TASK-005.builder.md and implement TASK-005 exactly as it says.` |
| the design check reports `look` differences (page background, link/button colour, underline, text hard to see, borders) | they block on purpose: that is what makes a screen look different. Fix the build — or, if you decide a difference is acceptable (e.g. a faint input border the client confirmed), add a line to `plan/design-accepted.md`: `| input "email" | border colour | client confirmed |`. Only you edit that file. |
| a pack has no design spec | `node tools/design-spec.mjs extract inputs/ux/<file>.html#<screen>` |
